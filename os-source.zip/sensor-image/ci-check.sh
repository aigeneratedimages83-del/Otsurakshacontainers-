#!/usr/bin/env bash
# Run by the GitHub workflow after the ISO is built: fails the build if something the console screen needs is missing.
# usage: sudo ./sensor-image/ci-check.sh out/otsense-sensor.iso   (kept inside source.zip so the workflow file never has to change again)
set -euo pipefail
ISO="${1:?iso path}"
apt-get install -y -qq squashfs-tools xorriso >/dev/null
mkdir -p /mnt/iso && mount -o loop,ro "$ISO" /mnt/iso
SQ="$(find /mnt/iso -name filesystem.squashfs | head -1)"
unsquashfs -l "$SQ" > /tmp/f.txt
bad=0
need() { if grep -q "$1" /tmp/f.txt; then echo "ok      $2"; else echo "MISSING $2"; bad=1; fi; }
need "opt/otsense/otsense.py"               "sensor program"
if [ -n "${CONTAINER_TAR:-}" ]; then       # container build: Docker and the sensor container must be inside the ISO
  need "usr/s\?bin/dockerd"                    "Docker engine"
  need "opt/otsense/container.mode"           "container mode marker"
  need "opt/otsense/container-image.tar.gz"   "sensor container image"
fi
need "opt/otsense/otsense-console.py"       "console screen program"
need "opt/otsense/run-sensor.sh"            "boot script"
need "etc/systemd/system/otsense-console.service" "console screen service"
need "etc/systemd/system/multi-user.target.wants/otsense-console.service" "console screen enabled at boot"
need "etc/systemd/system/multi-user.target.wants/otsense-sensor.service"  "sensor enabled at boot"
need "etc/systemd/system/getty@tty1.service" "tty1 reserved for the console screen"
need "sbin/dhclient"                        "DHCP client"
need "opt/otsense/otsense-gui.py"           "graphical screen program"
need "opt/otsense/otsense-sra.py"           "remote access (SRA) port script"
need "opt/otsense/otsense-screen.sh"        "screen launcher"
need "usr/bin/Xorg"                         "X server"
need "usr/bin/xinit"                        "xinit"
need "_tkinter"                             "python tkinter (buttons)"
need "opt/otsense/otsense-data.sh"            "settings disk script (OVA)"
need "etc/systemd/system/multi-user.target.wants/otsense-data.service" "settings disk enabled at boot"
need "systemd-timesyncd"                    "time sync (NTP)"
need "bin/ping"                             "ping"
need "_curses"                              "python curses module"
echo "--- boot menu timeout inside the ISO (isolinux: 10 = 1 second)"
grep -H -E '^[[:space:]]*timeout' /mnt/iso/isolinux/*.cfg 2>/dev/null || echo "(no isolinux timeout line found)"
xorriso -osirrox on -indev "$ISO" -extract /isolinux/isolinux.cfg /tmp/iso.cfg >/dev/null 2>&1 && grep -iE "timeout|prompt" /tmp/iso.cfg || echo "(could not read isolinux.cfg)"
T="$(grep -iE "^[[:space:]]*timeout" /tmp/iso.cfg 2>/dev/null | awk "{print \$2}" | head -1)"
if [ -z "$T" ] || [ "$T" -eq 0 ] || [ "$T" -gt 50 ]; then echo "MISSING boot menu auto-start (timeout=$T): the menu would wait for a key"; bad=1; else echo "ok      boot menu starts by itself"; fi
umount /mnt/iso
[ "$bad" = 0 ] || { echo "CHECK FAILED"; exit 1; }
echo "all checks passed"
