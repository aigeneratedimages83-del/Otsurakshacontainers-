#!/usr/bin/env python3
"""OT Sense console screen for the Raspberry Pi / Ubuntu image (HDMI or VM console): interfaces, services, site settings, actions menu.
Wi-Fi can be the management port (internet, central, web page); every wired port is then a SPAN/capture port.
Reuses the drawing helpers of otsense-console.py (same folder). Settings live in /etc/otsense/sensor.conf; changes are applied by firstboot.sh (FORCE=1)."""
import curses, importlib.util, ipaddress, json, os, re, shlex, socket, subprocess, sys, threading, time
from urllib.parse import urlparse

D = os.environ.get("D", "/opt/otsense")
CONF = os.environ.get("CONF", "/etc/otsense/sensor.conf")
APPLY = os.environ.get("APPLY", os.path.join(D, "firstboot.sh"))
CONTAINER = "otsense-sensor"
spec = importlib.util.spec_from_file_location("otc", os.path.join(D, "otsense-console.py"))
otc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(otc)
put, box, tag, dialog, ask, choose, sh, rd = otc.put, otc.box, otc.tag, otc.dialog, otc.ask, otc.choose, otc.sh, otc.rd
C = otc.C


# ------------------------------------------------------------------ settings file
def read_conf():
    d = {}
    try:
        for line in open(CONF):
            m = re.match(r"^([A-Z_][A-Z0-9_]*)=(.*)$", line.strip())
            if m:
                try:
                    v = shlex.split(m.group(2))
                    d[m.group(1)] = v[0] if v else ""
                except ValueError:
                    d[m.group(1)] = m.group(2).strip("'\"")
    except OSError:
        pass
    return d


def save_conf(upd):
    lines, seen = [], set()
    try:
        lines = open(CONF).read().splitlines()
    except OSError:
        pass
    out = []
    for line in lines:
        m = re.match(r"^([A-Z_][A-Z0-9_]*)=", line.strip())
        if m and m.group(1) in upd:
            out.append("%s=%s" % (m.group(1), shlex.quote(upd[m.group(1)])))
            seen.add(m.group(1))
        else:
            out.append(line)
    for k, v in upd.items():
        if k not in seen:
            out.append("%s=%s" % (k, shlex.quote(v)))
    tmp = CONF + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write("\n".join(out) + "\n")
    os.replace(tmp, CONF)


def apply_conf(scr, title, netonly):
    dialog(scr, title, ["Applying, please wait (up to a minute)..."], wait=False)
    env = dict(os.environ, FORCE="1", NETONLY="1" if netonly else "0")
    try:
        r = subprocess.run([APPLY], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, timeout=600)
        tail = [l for l in r.stdout.splitlines() if l.strip()][-6:]
    except Exception as e:
        tail = [str(e)]
    return tail


# ------------------------------------------------------------------ ports
def ports():
    """[(name, kind)] kind = wifi | wired"""
    out = []
    env = os.environ.get("NICS")
    if env:
        return [(n, "wired") for n in env.split()] + ([(os.environ["WIFI"], "wifi")] if os.environ.get("WIFI") else [])
    try:
        for n in sorted(os.listdir("/sys/class/net")):
            if re.match(r"^(lo|docker|veth|br-|virbr|tun|tap|ifb|bond|dummy|sit)", n) or not os.path.exists("/sys/class/net/%s/device" % n):
                continue
            wifi = os.path.isdir("/sys/class/net/%s/wireless" % n) or os.path.isdir("/sys/class/net/%s/phy80211" % n)
            out.append((n, "wifi" if wifi else "wired"))
    except OSError:
        pass
    return out


def mgmt_of(cfg):
    p = ports()
    names = [n for n, _ in p]
    if cfg.get("MGMT_PORT") in names:
        return cfg["MGMT_PORT"]
    wifi = [n for n, k in p if k == "wifi"]
    if wifi and cfg.get("WIFI_SSID"):
        return wifi[0]
    wired = [n for n, k in p if k == "wired"]
    return wired[0] if wired else ""


def wifi_link(n):
    rc, o = sh(["iw", "dev", n, "link"])
    m = re.search(r"SSID: (.+)", o or "")
    s = re.search(r"signal: (-?\d+) dBm", o or "")
    return ("%s  %s dBm" % (m.group(1), s.group(1))) if m else ("not connected" if rc == 0 else "")


# ------------------------------------------------------------------ status
class Status(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.daemon = True
        self.d = {"ports": [], "mgmt": "", "ip": "", "gw": "", "ping": "", "state": "?", "pw": "", "cfg": {}, "dns": "", "tcp": "", "ntp": ""}
        self.t_slow = 0.0

    def run(self):
        while True:
            try:
                self.collect()
            except Exception:
                pass
            time.sleep(3)

    def collect(self):
        d = dict(self.d)
        cfg = read_conf()
        mg = mgmt_of(cfg)
        d["cfg"], d["mgmt"] = cfg, mg
        pl = []
        for n, kind in ports():
            st = rd("/sys/class/net/%s/operstate" % n) or "?"
            pl.append({"n": n, "kind": kind, "role": "MGMT" if n == mg else ("SPAN" if kind == "wired" else "unused"), "state": st,
                       "ip": otc.ip_of(n) if n == mg else "", "rx": rd("/sys/class/net/%s/statistics/rx_packets" % n) or "0", "mac": rd("/sys/class/net/%s/address" % n),
                       "link": wifi_link(n) if kind == "wifi" else ""})
            if kind == "wired" and n != mg:       # capture ports must be up and promiscuous
                fl = int(rd("/sys/class/net/%s/flags" % n) or "0", 16) if True else 0
                if not (fl & 1) or not (fl & 0x100):
                    sh(["ip", "link", "set", n, "up", "promisc", "on"])
        d["ports"] = pl
        d["ip"] = otc.ip_of(mg) if mg else ""
        d["gw"] = otc.gateway_of(mg) if d["ip"] else ""
        d["ping"] = ""
        if d["gw"]:
            rc, o = sh(["ping", "-c", "1", "-W", "1", d["gw"]], timeout=4)
            m = re.search(r"time=([\d.]+) ms", o or "")
            d["ping"] = (m.group(1) + " ms") if m else "no reply"
        rc, o = sh(["docker", "inspect", "-f", "{{.State.Running}}", CONTAINER], timeout=6)
        d["state"] = "active" if o.strip() == "true" else ("stopped" if o.strip() == "false" else "not created yet")
        if time.time() - self.t_slow > 20:
            self.t_slow = time.time()
            rc, o = sh(["docker", "logs", "--tail", "400", CONTAINER], timeout=8)
            m = re.findall(r"password[^A-Za-z0-9]{1,6}([A-Za-z0-9_\-]{6,})", o or "", re.I)
            d["pw"] = m[-1] if m else d.get("pw", "")
            d["ntp"] = sh(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])[1].strip()
            c = cfg.get("CENTRAL", "")
            d["dns"], d["tcp"] = otc.quick_central(c) if c else ("", "")
        self.d = d


def web_url(d):
    ip = d.get("ip", "").split("/")[0]
    return "http://%s:8080" % ip if ip else "http://<no address yet>:8080"


# ------------------------------------------------------------------ actions
def act_wifi(scr, st):
    wifi = [n for n, k in ports() if k == "wifi"]
    if not wifi:
        dialog(scr, "Wi-Fi", ["No Wi-Fi card found on this device.", "(A Raspberry Pi 4/5 has one built in; in a VM there is none.)"])
        return
    w = wifi[0]
    dialog(scr, "Wi-Fi", ["Searching for Wi-Fi networks on %s ..." % w], wait=False)
    sh(["ip", "link", "set", w, "up"])
    rc, o = sh(["iw", "dev", w, "scan"], timeout=25)
    nets = {}
    cur = None
    for line in (o or "").splitlines():
        m = re.search(r"signal: (-?\d+)", line)
        if m:
            cur = int(m.group(1))
        m = re.match(r"\s*SSID: (.+)", line)
        if m and m.group(1).strip():
            nets[m.group(1).strip()] = max(nets.get(m.group(1).strip(), -200), cur if cur is not None else -100)
    names = sorted(nets, key=lambda k: -nets[k])[:12]
    k = choose(scr, "Wi-Fi network for MANAGEMENT (internet, central, web page)", ["%s   (%d dBm)" % (n, nets[n]) for n in names] + ["Type the name myself"])
    if k is None:
        return
    ssid = names[k] if k < len(names) else ask(scr, "Wi-Fi", "Wi-Fi network name")
    if not ssid:
        return
    cfg = read_conf()
    psk = ask(scr, "Wi-Fi", "Password of '%s' (empty = open network)" % ssid, cfg.get("WIFI_PSK", "") if cfg.get("WIFI_SSID") == ssid else "")
    if psk is None:
        return
    if psk and not 8 <= len(psk) <= 63:
        dialog(scr, "Wi-Fi", ["A Wi-Fi password has 8 to 63 characters."])
        return
    cc = ask(scr, "Wi-Fi", "Country code of this Wi-Fi (2 letters, e.g. IN, US, GB, DE)", cfg.get("WIFI_COUNTRY", "") or "IN")
    if not cc or not re.match(r"^[A-Za-z]{2}$", cc):
        dialog(scr, "Wi-Fi", ["Please give the 2-letter country code."])
        return
    save_conf({"WIFI_SSID": ssid, "WIFI_PSK": psk, "WIFI_COUNTRY": cc.upper(), "MGMT_PORT": w})
    tail = apply_conf(scr, "Wi-Fi", True)
    for _ in range(25):
        if otc.ip_of(w):
            break
        time.sleep(1)
    st.collect()
    dialog(scr, "Wi-Fi", ["Management port is now %s (%s)." % (w, ssid), "Address: %s" % (otc.ip_of(w) or "none yet - check the password and signal")] + [""] + tail)


def act_network(scr, st):
    cfg = read_conf()
    mg = mgmt_of(cfg)
    k = choose(scr, "Management port address (%s)" % (mg or "no port"), ["Automatic (DHCP)", "Fixed IP address"], 0 if cfg.get("MGMT_MODE", "dhcp") != "static" else 1)
    if k is None:
        return
    if k == 0:
        save_conf({"MGMT_MODE": "dhcp"})
    else:
        ip = ask(scr, "Fixed IP", "IP address with prefix, for example 192.168.1.50/24", cfg.get("IP_CIDR", ""))
        if not ip:
            return
        try:
            ipaddress.ip_interface(ip)
        except ValueError:
            dialog(scr, "Not valid", ["%r is not an IP address with prefix. Example: 192.168.1.50/24" % ip])
            return
        gw = ask(scr, "Fixed IP", "Gateway (router) address", cfg.get("GATEWAY", ""))
        dns = ask(scr, "Fixed IP", "DNS server(s), comma separated", cfg.get("DNS", "") or "8.8.8.8")
        if gw is None or dns is None:
            return
        save_conf({"MGMT_MODE": "static", "IP_CIDR": ip, "GATEWAY": gw, "DNS": dns})
    tail = apply_conf(scr, "Network", False)
    st.collect()
    dialog(scr, "Network", ["Address: %s" % (st.d.get("ip") or "none yet")] + tail)


def act_ports(scr, st):
    p = ports()
    if not p:
        dialog(scr, "Ports", ["No network port found."])
        return
    cfg = read_conf()
    cur = mgmt_of(cfg)
    k = choose(scr, "Which port is the MANAGEMENT port? (all wired ports left = SPAN)", ["%s  (%s)%s" % (n, kind, "   <- now" if n == cur else "") for n, kind in p], [n for n, _ in p].index(cur) if cur else 0)
    if k is None:
        return
    save_conf({"MGMT_PORT": p[k][0]})
    tail = apply_conf(scr, "Ports", False)
    st.collect()
    dialog(scr, "Ports", ["Management: %s" % p[k][0], "SPAN: %s" % (", ".join(n for n, kind in p if kind == "wired" and n != p[k][0]) or "none")] + [""] + tail)


def act_central(scr, st):
    cfg = read_conf()
    c = ask(scr, "Central server", "Web address of central, e.g. https://central.example.com", cfg.get("CENTRAL", ""))
    if c is None:
        return
    if c and "://" not in c:
        c = "https://" + c
    t = ask(scr, "Central server", "Site token (copy it from central: Sites tab)", cfg.get("TOKEN", ""))
    if t is None:
        return
    s = ask(scr, "Central server", "Site name", cfg.get("SITE", "") or socket.gethostname())
    if s is None:
        return
    save_conf({"CENTRAL": c, "TOKEN": t, "SITE": s})
    tail = apply_conf(scr, "Central server", False)
    dialog(scr, "Central server", ["Saved. The sensor was restarted and connects to:", c, ""] + tail)


def act_test(scr, st):
    dialog(scr, "Test connectivity", ["Testing, please wait..."], wait=False)
    st.collect()
    d, out = st.d, []

    def line(ok, t):
        out.append("[ %s ] %s" % ({True: " OK ", False: "FAIL", None: " -- "}[ok], t))
    line(bool(d["ip"]), "Management port %s: %s" % (d["mgmt"] or "none", d["ip"] or "no address (Wi-Fi password? cable? DHCP?)"))
    if d["gw"]:
        line(d["ping"] != "no reply", "Gateway %s: %s" % (d["gw"], d["ping"]))
    c = d["cfg"].get("CENTRAL", "")
    if not c:
        line(None, "Central address not set - choose 'Central server'")
    else:
        try:
            sys.path.insert(0, "/opt/otsense/src")
            import otsense
            steps, _m = otsense.test_central(c, d["cfg"].get("TOKEN", ""), "/opt/otsense-sensor/ca.crt", False, d["cfg"].get("SITE", ""), timeout=6)
            for label, ok, detail in steps:
                line(ok, "%s: %s" % (label, detail))
        except Exception:
            dns, tcp = otc.quick_central(c)
            line(None, "DNS: %s   %s" % (dns, tcp))
    dialog(scr, "Test connectivity", out)


def act_ping(scr, st):
    host = ask(scr, "Ping", "Host name or IP to ping", st.d.get("gw") or "8.8.8.8")
    if not host or not re.match(r"^[A-Za-z0-9._:-]+$", host):
        return
    dialog(scr, "Ping", ["Pinging %s ..." % host], wait=False)
    dialog(scr, "Ping %s" % host, (sh(["ping", "-c", "4", "-W", "2", host], timeout=15)[1].splitlines()) or ["no output"])


def act_restart_sensor(scr, st):
    sh(["docker", "restart", CONTAINER], timeout=60)
    dialog(scr, "Sensor", ["The sensor container was restarted."])


def act_log(scr, st):
    dialog(scr, "Sensor log (last lines)", (sh(["docker", "logs", "--tail", "60", CONTAINER], timeout=10)[1].splitlines() or ["no log yet"])[-80:])


def act_shell(scr, st):
    curses.def_prog_mode()
    curses.endwin()
    os.system("clear; echo 'OT Sense - log in as the service account (otsense). Type exit to return to the menu.'; /bin/login")
    curses.reset_prog_mode()
    scr.clear()


def act_reboot(scr, st):
    if choose(scr, "Restart this sensor?", ["No", "Yes, restart now"]) == 1:
        sh(["systemctl", "reboot"])


def act_off(scr, st):
    if choose(scr, "Power off this sensor?", ["No", "Yes, power off now"]) == 1:
        sh(["systemctl", "poweroff"])


ACTIONS = [("Wi-Fi network", act_wifi), ("Network address", act_network), ("Ports (mgmt/SPAN)", act_ports), ("Central server", act_central),
           ("Test connectivity", act_test), ("Ping", act_ping), ("Restart sensor", act_restart_sensor), ("Show log", act_log),
           ("Login (shell)", act_shell), ("Restart", act_reboot), ("Power off", act_off)]
COLS = 4


def draw(scr, st, sel):
    scr.erase()
    h, w = scr.getmaxyx()
    d, cfg, bw = st.d, st.d.get("cfg", {}), w - 2
    put(scr, 0, 1, "OT Sense Appliance (Raspberry Pi), Site: %s" % (cfg.get("SITE") or "not set"), C["head"] | curses.A_BOLD)
    t = time.strftime("%H:%M:%S UTC", time.gmtime())
    put(scr, 0, max(1, w - len(t) - 2), t)
    y = 1
    nrows = (len(ACTIONS) + COLS - 1) // COLS
    room = max(1, h - (2 + 4 + 7 + nrows + 2 + 2))
    pl = d["ports"][:room]
    box(scr, y, 1, len(pl) + 2 if pl else 3, bw, "Interfaces", C["box"])
    if not pl:
        put(scr, y + 1, 3, "No network port found.", C["bad"])
    for i, p in enumerate(pl):
        x = tag(scr, y + 1 + i, 3, p["n"], C["ok"] if p["state"] == "up" else C["bad"])
        put(scr, y + 1 + i, x, "%-6s %-4s " % (p["role"], p["kind"]))
        if p["role"] == "MGMT":
            put(scr, y + 1 + i, x + 12, ("%s  gw %s  ping %s%s" % (p["ip"], d["gw"] or "-", d["ping"] or "-", ("  [%s]" % p["link"]) if p["link"] else "")) if p["ip"] else "waiting for an address...", 0 if p["ip"] else C["warn"])
        elif p["kind"] == "wired":
            put(scr, y + 1 + i, x + 12, "capture, no IP  rx %s" % p["rx"])
        else:
            put(scr, y + 1 + i, x + 12, "not used")
    y += (len(pl) + 2) if pl else 3
    box(scr, y, 1, 4, bw, "Services", C["box"])
    x = tag(scr, y + 1, 3, "Sensor", C["ok"] if d["state"] == "active" else C["bad"])
    put(scr, y + 1, x, "Active" if d["state"] == "active" else "%s - see Show log" % d["state"], C["ok"] if d["state"] == "active" else C["bad"])
    x = tag(scr, y + 2, 3, "Web page", C["ok"] if d["ip"] else C["warn"])
    put(scr, y + 2, x, "%s   setup password: %s   (or central login)" % (web_url(d), d["pw"] or "..."), curses.A_BOLD)
    y += 4
    box(scr, y, 1, 7, bw, "Site (settings from central)", C["box"])
    put(scr, y + 1, 3, "Site name   : %s" % (cfg.get("SITE") or "not set"))
    put(scr, y + 2, 3, "Central     : %s" % (cfg.get("CENTRAL") or "not set - choose 'Central server'"))
    put(scr, y + 3, 3, "Server      : DNS %s   HTTPS %s" % (d["dns"] or "-", d["tcp"] or "-"), C["ok"] if "reachable" in d["tcp"] else C["warn"])
    put(scr, y + 4, 3, "Sensor name : %s   IP: %s %s" % (cfg.get("HOSTNAME_FQDN") or socket.gethostname(), "fixed" if cfg.get("MGMT_MODE") == "static" else "DHCP", d["ip"] or "waiting..."))
    put(scr, y + 5, 3, "Wi-Fi: %s   NTP: %s (sync %s)" % (cfg.get("WIFI_SSID") or "not used", cfg.get("NTP") or "not set", d.get("ntp") or "?"))
    y += 7
    box(scr, y, 1, nrows + 2, bw, "Actions", C["box"])
    cw = (bw - 4) // COLS
    for i, (name, _) in enumerate(ACTIONS):
        r, c = divmod(i, COLS)
        put(scr, y + 1 + r, 3 + c * cw, "[ %s ]" % name, C["sel"] if i == sel else curses.A_BOLD)
    put(scr, h - 1, 1, "Arrow keys + Enter. Changes are applied at once.", C["warn"])
    scr.refresh()


def main(scr):
    otc.colors()
    try:
        curses.curs_set(0)
    except curses.error:
        pass
    scr.keypad(True)
    scr.timeout(1000)
    st = Status()
    st.start()
    sel = 0
    while True:
        draw(scr, st, sel)
        k = scr.getch()
        if k == curses.KEY_LEFT:
            sel = max(0, sel - 1)
        elif k == curses.KEY_RIGHT:
            sel = min(len(ACTIONS) - 1, sel + 1)
        elif k == curses.KEY_UP:
            sel = sel - COLS if sel - COLS >= 0 else sel
        elif k == curses.KEY_DOWN:
            sel = sel + COLS if sel + COLS < len(ACTIONS) else sel
        elif k in (10, 13, curses.KEY_ENTER):
            try:
                ACTIONS[sel][1](scr, st)
            except Exception as e:
                dialog(scr, "Error", ["%s: %s" % (type(e).__name__, e)])
            st.collect()
        elif k == curses.KEY_RESIZE:
            scr.clear()


if __name__ == "__main__":
    os.environ.setdefault("TERM", "linux")
    os.environ.setdefault("ESCDELAY", "50")
    while True:
        try:
            curses.wrapper(main)
        except KeyboardInterrupt:
            pass
        except Exception as e:
            sys.stderr.write("\nOT Sense console error: %s: %s\nrestarting in 3 seconds...\n" % (type(e).__name__, e))
            time.sleep(3)
