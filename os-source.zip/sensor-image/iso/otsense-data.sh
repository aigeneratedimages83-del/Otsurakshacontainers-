#!/bin/bash
# OVA only: a second disk labelled OTDATA keeps the sensor's settings (address, central link, password) across reboots.
# Nothing is ever formatted here: if no disk with that label exists (plain ISO), the sensor simply runs without saved settings.
STATE="${STATE:-/var/lib/otsense}"
DISKS="$(lsblk -dno TYPE 2>/dev/null | grep -c '^disk$' || true)"
DEV=""
if [ "${DISKS:-0}" -ge 2 ]; then
  udevadm settle -t 5 2>/dev/null || true
  for i in 1 2 3 4 5 6 7 8; do DEV="$(blkid -L OTDATA 2>/dev/null || true)"; [ -n "$DEV" ] && break; sleep 1; done
fi
[ -n "$DEV" ] || { echo "[otsense-data] no OTDATA disk - running without saved settings"; exit 0; }
mkdir -p "$STATE"
mountpoint -q "$STATE" || mount -o noatime "$DEV" "$STATE"
chmod 700 "$STATE"
echo "[otsense-data] settings disk $DEV mounted on $STATE"
