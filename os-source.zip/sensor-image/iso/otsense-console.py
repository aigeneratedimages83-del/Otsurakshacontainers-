#!/usr/bin/env python3
"""OT Sense appliance console - the text screen on the VM / monitor (like the Armis collector screen).

  python3 otsense-console.py          the screen (started on tty1 by otsense-console.service)
  python3 otsense-console.py --net    bring the network up (used at boot by run-sensor.sh)
  python3 otsense-console.py --ports  print MGMT=... CAP=... for run-sensor.sh

Needs only python3 + iproute2 + isc-dhcp-client + iputils-ping, all inside the ISO. No graphics: works with nomodeset.
Test without changing anything:  DRY_RUN=1 NICS="eth0 eth1" STATE=/tmp/st RUN=/tmp/rn python3 otsense-console.py --net
"""
import curses, ipaddress, json, os, re, shlex, signal, socket, subprocess, sys, threading, time
from urllib.parse import urlparse

D = os.environ.get("D", "/opt/otsense")
STATE = os.environ.get("STATE", "/var/lib/otsense")
RUN = os.environ.get("RUN", "/run/otsense")
DRY = os.environ.get("DRY_RUN", "0") == "1"
NETJ = os.path.join(STATE, "net.json")
SENSORJ = os.path.join(STATE, "sensor.json")
OVERRIDE = os.path.join(STATE, "override.env")
PWFILE = os.path.join(STATE, "ui-password")
RUNPW = os.path.join(RUN, "ui-password")
SERVICE = "otsense-sensor"
SKIP = re.compile(r"^(lo|docker|veth|br-|virbr|tun|tap|ifb|bond|dummy|sit|wl)")


# ------------------------------------------------------------------ helpers
def sh(cmd, timeout=10):
    if DRY:
        print("+ " + " ".join(cmd))
        return 0, ""
    try:
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, timeout=timeout)
        return r.returncode, (r.stdout or "").strip()
    except Exception as e:
        return 1, str(e)


def rd(path):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return ""


def read_json(path):
    try:
        with open(path) as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def write_private(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(text)
    os.replace(tmp, path)


def nics():
    env = os.environ.get("NICS")
    if env:
        return env.split()
    out = []
    try:
        for n in sorted(os.listdir("/sys/class/net")):
            if not SKIP.match(n) and os.path.exists("/sys/class/net/%s/device" % n):
                out.append(n)
    except OSError:
        pass
    return out


def ip_of(n):
    rc, o = sh(["ip", "-o", "-4", "addr", "show", "dev", n]) if not DRY else (1, "")
    m = re.search(r"inet (\d+\.\d+\.\d+\.\d+/\d+)", o or "")
    return m.group(1) if m else ""


def gateway_of(n=None):
    rc, o = sh(["ip", "-4", "route", "show", "default"]) if not DRY else (1, "")
    for line in (o or "").splitlines():
        m = re.search(r"default via (\S+) dev (\S+)", line)
        if m and (n is None or m.group(2) == n):
            return m.group(1)
    return ""


# ------------------------------------------------------------------ network
def load_net():
    c = {"mgmt": "", "mode": "dhcp", "ip_cidr": "", "gateway": "", "dns": ""}
    d = read_json(NETJ)
    if d:
        c.update({k: d[k] for k in c if k in d})
    else:   # first boot: take what central stamped into the ISO (run-sensor.sh passes it as MODE / IP_CIDR / GATEWAY / DNS)
        if os.environ.get("MODE") == "static" and os.environ.get("IP_CIDR"):
            c.update(mode="static", ip_cidr=os.environ.get("IP_CIDR", ""), gateway=os.environ.get("GATEWAY", ""), dns=os.environ.get("DNS", ""))
    return c


def save_net(c):
    if not DRY:
        write_private(NETJ, json.dumps(c, indent=1))


_sra = []


def sra():
    """The shared remote-access (SRA) module otsense-sra.py (settings in sra.json)."""
    if not _sra:
        import importlib.util
        spec = importlib.util.spec_from_file_location("otsra", os.path.join(D, "otsense-sra.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        m.STATE, m.RUN, m.CFG, m.ENVF, m.DRY = STATE, RUN, os.path.join(STATE, "sra.json"), os.path.join(RUN, "sra.env"), DRY
        _sra.append(m)
    return _sra[0]


def sra_port(mg=None):
    """Name of the remote-access port in use: configured, present, wired and not the management port. Else ''."""
    try:
        c = sra().load()
    except Exception:
        return ""
    p = c.get("port") or ""
    mg = mg if mg is not None else mgmt_port()
    return p if (p and p in nics() and p != mg) else ""


def mgmt_port(c=None):
    c = c or load_net()
    p = nics()
    return c["mgmt"] if c["mgmt"] in p else (p[0] if p else "")


def stop_dhcp(n):
    pf = "/run/dhclient-%s.pid" % n
    pid = rd(pf)
    if pid.isdigit() and not DRY:
        try:
            os.kill(int(pid), signal.SIGTERM)
        except OSError:
            pass
    if not DRY:
        try:
            os.remove(pf)
        except OSError:
            pass


def apply_net(log=print, wait=25):
    """Management port + remote-access (SRA) port, then the same as before. Wrapper so every return path of the core also sets up SRA."""
    ok = _apply_net_core(log, wait)
    try:
        sra().apply()
    except Exception as e:      # noqa
        log("remote-access (SRA) port: %s" % e)
    try:
        for ln in sra().sitenet_apply():        # DNS / time server entered on the sensor
            log(ln)
    except Exception as e:      # noqa
        log("site DNS / time server: %s" % e)
    return ok


def _apply_net_core(log=print, wait=25):
    """First physical port = management (DHCP or fixed IP), every other port = capture (SPAN: no IP, promiscuous); the SRA port is neither."""
    c = load_net()
    ports = nics()
    if not ports:
        log("No network port found.")
        return False
    mg = mgmt_port(c)
    c["mgmt"] = mg
    save_net(c)
    sp = sra_port(mg)
    log("management port: %s   remote-access (SRA) port: %s   capture ports: %s" % (mg, sp or "none", ", ".join(p for p in ports if p not in (mg, sp)) or "none"))
    for p in ports:
        if p == mg or p == sp:
            continue
        stop_dhcp(p)
        sh(["ip", "addr", "flush", "dev", p])
        sh(["ip", "link", "set", p, "up", "promisc", "on"])
    stop_dhcp(mg)
    sh(["ip", "-4", "route", "flush", "dev", mg])
    sh(["ip", "addr", "flush", "dev", mg])
    sh(["ip", "link", "set", mg, "promisc", "off"])
    sh(["ip", "link", "set", mg, "up"])
    if c["mode"] == "static":
        try:
            ipaddress.ip_interface(c["ip_cidr"])
        except ValueError:
            log("Fixed address %r is not valid (use for example 192.168.1.50/24)." % c["ip_cidr"])
            return False
        sh(["ip", "addr", "add", c["ip_cidr"], "dev", mg])
        if c["gateway"]:
            sh(["ip", "route", "replace", "default", "via", c["gateway"], "dev", mg])
        if c["dns"] and not DRY:
            with open("/etc/resolv.conf", "w") as f:
                for x in re.split(r"[ ,]+", c["dns"].strip()):
                    if x:
                        f.write("nameserver %s\n" % x)
        log("fixed address %s" % c["ip_cidr"])
        return True
    # DHCP: dhclient keeps asking in the background until an address arrives
    rc, o = sh(["dhclient", "-4", "-nw", "-pf", "/run/dhclient-%s.pid" % mg, "-lf", os.path.join(STATE, "dhclient-%s.leases" % mg), mg], timeout=15)
    if rc != 0:
        log("dhclient problem: %s" % o[-200:])
    if DRY:
        return True
    for _ in range(wait):
        if ip_of(mg):
            log("address %s" % ip_of(mg))
            return True
        time.sleep(1)
    log("no address from DHCP yet (still trying in the background)")
    return False


# ------------------------------------------------------------------ status (background thread)
class Status(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.daemon = True
        self.d = {"ports": [], "mgmt": "", "ip": "", "gw": "", "ping": "", "active": "?", "site": "", "central": "", "dns": "", "tcp": "", "pw": ""}
        self.lastc = 0.0
        self.central_key = None
        self.known = None
        self.changed_at = 0.0

    def run(self):
        while True:
            try:
                self.collect()
            except Exception:
                pass
            time.sleep(3)

    def watch_ports(self, mg):
        keep_capture_ports_up(mg)
        cur = tuple(nics())
        if self.known is None:
            self.known = cur
        elif cur != self.known:
            if not self.changed_at:
                self.changed_at = time.time()
            elif time.time() - self.changed_at > 6:      # port list stable for a few seconds: restart the sensor so it uses the new port
                self.known, self.changed_at = cur, 0.0
                restart_sensor()
        else:
            self.changed_at = 0.0

    def collect(self):
        d = dict(self.d)
        c = load_net()
        mg = mgmt_port(c)
        self.watch_ports(mg)
        d["mgmt"] = mg
        d["mode"] = c["mode"]
        ports = []
        sp = sra_port(mg)
        try:
            sc = sra().load() if sp else {}
            si_ = sra().ifname(sc) if sp else ""
        except Exception:
            sc, si_ = {}, ""
        d["sra"] = {"port": sp, "vlan": sc.get("vlan") or 0, "ip_cidr": sc.get("ip_cidr", ""), "gateway": sc.get("gateway", ""), "extra": sc.get("extra") or []} if sp else {}
        for n in nics():
            st = rd("/sys/class/net/%s/operstate" % n) or "?"
            rx = rd("/sys/class/net/%s/statistics/rx_packets" % n) or "0"
            ports.append({"n": n, "mac": rd("/sys/class/net/%s/address" % n), "role": "MGMT" if n == mg else "SRA" if n == sp else "SPAN", "state": st,
                          "ip": ip_of(n) if n == mg else (ip_of(si_) if n == sp else ""), "rx": rx})
        d["ports"] = ports
        d["ip"] = ip_of(mg) if mg else ""
        d["gw"] = gateway_of(mg) if d["ip"] else ""
        d["ping"] = ""
        if d["gw"]:
            rc, o = sh(["ping", "-c", "1", "-W", "1", d["gw"]], timeout=4)
            m = re.search(r"time=([\d.]+) ms", o or "")
            d["ping"] = (m.group(1) + " ms") if m else "no reply"
        rc, o = sh(["systemctl", "is-active", SERVICE])
        d["active"] = (o or "?").splitlines()[-1] if o else "?"
        s = read_json(SENSORJ)
        d["site"] = s.get("site", "")
        d["central"] = s.get("central", "")
        d["pw"] = rd(PWFILE) or rd(RUNPW)
        d["si"] = read_json(os.path.join(RUN, "site-info.json"))
        d["cs"] = read_json(os.path.join(RUN, "central-status.json"))
        if time.time() - getattr(self, "ntp_at", 0) > 10:
            self.ntp_at = time.time()
            self.ntp_sync = sh(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])[1].strip()
        d["ntp_sync"] = getattr(self, "ntp_sync", "")
        key = (d["central"], d["ip"])
        if d["central"] and (key != self.central_key or time.time() - self.lastc > 30):
            self.central_key, self.lastc = key, time.time()
            d["dns"], d["tcp"] = quick_central(d["central"])
        if not d["central"]:
            d["dns"], d["tcp"] = "", ""
        self.d = d


def keep_capture_ports_up(mg):
    """every port except the management port must be up and promiscuous (also a port added while the sensor runs)"""
    sp = sra_port(mg)
    for n in nics():
        if n == mg or n == sp or DRY:
            continue
        try:
            fl = int(rd("/sys/class/net/%s/flags" % n) or "0", 16)
        except ValueError:
            continue
        if not (fl & 0x1) or not (fl & 0x100):
            sh(["ip", "addr", "flush", "dev", n])
            sh(["ip", "link", "set", n, "up", "promisc", "on"])


def read_cs():
    return read_json(os.path.join(RUN, "central-status.json")) or {}


def web_pw():
    for p in (PWFILE, RUNPW):
        v = rd(p)
        if v:
            return v.strip()
    return ""


def link_state(d):
    """(state, text) of the sensor's link to central, from what the sensor program reports: ok = data went through recently, else down."""
    cs = d.get("cs") or {}
    if not d.get("central"):
        return "none", "central address not set"
    la = cs.get("last_ok") or 0
    if not la:
        return "down", "not connected yet" + ((" - " + cs["error"][:60]) if cs.get("error") else "")
    age = time.time() - la
    lim = max(90, 3 * int(cs.get("interval") or 30))
    if age <= lim and not cs.get("error"):
        return "ok", "connected to central, last data %ds ago" % int(age)
    return "down", "NOT connected to central" + ((" - " + cs["error"][:60]) if cs.get("error") else ", last data %d min ago" % int(age // 60))


def blink_dot(state):
    """a dot that blinks once a second while the link is good (green), steady red when it is down"""
    if state == "ok":
        return ("\u25cf" if int(time.time()) % 2 == 0 else "\u25cb")
    return "\u25cf" if state == "down" else "-"


def act_ssh(scr, st):
    cs = st.d.get("cs") or {}
    on = sh(["systemctl", "is-active", "ssh"])[1].strip() == "active"
    k = choose(scr, "SSH (WinSCP / PuTTY) is now %s" % ("ON" if on else "off"), ["Turn SSH ON", "Turn SSH off", "Cancel"], 0 if not on else 1)
    if k is None or k == 2:
        return
    if k == 0:
        os.makedirs("/run/sshd", exist_ok=True)
        sh(["ssh-keygen", "-A"], timeout=60)
        sh(["systemctl", "unmask", "ssh"], timeout=10)
        rc, o = sh(["systemctl", "enable", "--now", "ssh"], timeout=40)
        time.sleep(1.5)
        try:
            with socket.create_connection(("127.0.0.1", 22), timeout=2):
                rc = 0
        except OSError:
            rc = rc or 1
            o = (o or "") + " " + sh(["journalctl", "-u", "ssh", "-n", "3", "--no-pager"])[1]
        dialog(scr, "SSH", ["SSH is ON." if rc == 0 else "Could not start SSH: " + (o or "").strip()[-120:], "",
                            "Login: user otsense   password: %s" % (st.d.get("pw") or "(see central, Show login)"),
                            "Address: %s   port 22   (WinSCP: protocol SCP)" % (st.d.get("ip") or "?"), "",
                            "Central can switch it too (Sites > sensor > Turn SSH on/off)."])
    else:
        sh(["systemctl", "disable", "--now", "ssh"], timeout=40)
        dialog(scr, "SSH", ["SSH is off."])


def quick_central(url):
    u = urlparse(url if "://" in url else "https://" + url)
    if not u.hostname:
        return "bad address", ""
    port = u.port or (443 if u.scheme == "https" else 80)
    try:
        ips = sorted({x[4][0] for x in socket.getaddrinfo(u.hostname, port, type=socket.SOCK_STREAM)})
    except OSError as e:
        return "cannot resolve %s" % u.hostname, ""
    try:
        socket.create_connection((u.hostname, port), timeout=3).close()
        return ", ".join(ips[:3]), "port %d reachable" % port
    except OSError as e:
        return ", ".join(ips[:3]), "cannot connect to port %d" % port


# ------------------------------------------------------------------ drawing helpers
def put(scr, y, x, s, attr=0):
    h, w = scr.getmaxyx()
    if y < 0 or y >= h or x >= w - 1:
        return
    try:
        scr.addstr(y, x, s[: w - 1 - x], attr)
    except curses.error:
        pass


def box(scr, y, x, h, w, title, attr=0):
    put(scr, y, x, "+" + "-" * (w - 2) + "+", attr)
    for r in range(1, h - 1):
        put(scr, y + r, x, "|", attr)
        put(scr, y + r, x + w - 1, "|", attr)
    put(scr, y + h - 1, x, "+" + "-" * (w - 2) + "+", attr)
    put(scr, y, x + 2, " %s " % title, attr | curses.A_BOLD)


C = {}


def colors():
    curses.start_color()
    for i, (name, fg) in enumerate([("ok", curses.COLOR_GREEN), ("bad", curses.COLOR_RED), ("head", curses.COLOR_MAGENTA),
                                    ("box", curses.COLOR_CYAN), ("warn", curses.COLOR_YELLOW)], 1):
        curses.init_pair(i, fg, curses.COLOR_BLACK)
        C[name] = curses.color_pair(i)
    curses.init_pair(9, curses.COLOR_BLACK, curses.COLOR_WHITE)
    C["sel"] = curses.color_pair(9)


def tag(scr, y, x, text, attr):
    put(scr, y, x, "[", 0)
    put(scr, y, x + 1, " %s " % text, attr | curses.A_BOLD)
    put(scr, y, x + len(text) + 4, "]", 0)
    return x + len(text) + 6


def dialog(scr, title, lines, wait=True):
    h, w = scr.getmaxyx()
    width = min(w - 4, 74)
    body = []
    for ln in lines:
        while len(ln) > width - 4:
            cut = ln.rfind(" ", 0, width - 4)
            cut = cut if cut > 10 else width - 4
            body.append(ln[:cut])
            ln = ln[cut:].lstrip()
        body.append(ln)
    page = max(3, h - 6)
    i = 0
    while True:
        chunk = body[i:i + page]
        more = i + page < len(body)
        bh = len(chunk) + 4
        y0, x0 = max(0, (h - bh) // 2), (w - width) // 2
        scr.erase()
        box(scr, y0, x0, bh, width, title, C["box"])
        for r, ln in enumerate(chunk):
            put(scr, y0 + 2 + r, x0 + 2, ln)
        if wait:
            put(scr, y0 + bh - 1, x0 + 3, " %s " % ("SPACE = more, other key = close" if more else "press any key"), C["warn"])
        scr.refresh()
        if not wait:
            return
        scr.timeout(-1)
        k = scr.getch()
        scr.timeout(1000)
        if more and k == ord(" "):
            i += page
            continue
        return


def ask(scr, title, label, default="", secret=False):
    h, w = scr.getmaxyx()
    width = min(w - 4, 70)
    val = default
    scr.timeout(-1)
    try:
        curses.curs_set(1)
    except curses.error:
        pass
    try:
        while True:
            y0, x0 = max(0, h // 2 - 3), (w - width) // 2
            scr.erase()
            box(scr, y0, x0, 6, width, title, C["box"])
            put(scr, y0 + 2, x0 + 2, label)
            shown = ("*" * len(val)) if secret else val
            shown = shown[-(width - 6):]
            put(scr, y0 + 3, x0 + 2, "> " + shown)
            put(scr, y0 + 5, x0 + 3, " Enter = OK    Esc = cancel ", C["warn"])
            scr.move(min(y0 + 3, h - 1), min(x0 + 4 + len(shown), w - 2))
            scr.refresh()
            k = scr.getch()
            if k in (10, 13, curses.KEY_ENTER):
                return val.strip()
            if k == 27:
                return None
            if k in (8, 127, curses.KEY_BACKSPACE):
                val = val[:-1]
            elif 32 <= k <= 126:
                val += chr(k)
    finally:
        try:
            curses.curs_set(0)
        except curses.error:
            pass
        scr.timeout(1000)


def choose(scr, title, options, idx=0):
    h, w = scr.getmaxyx()
    width = min(w - 4, 70)
    scr.timeout(-1)
    try:
        while True:
            bh = len(options) + 4
            y0, x0 = max(0, (h - bh) // 2), (w - width) // 2
            scr.erase()
            box(scr, y0, x0, bh, width, title, C["box"])
            for i, o in enumerate(options):
                put(scr, y0 + 2 + i, x0 + 2, " %s " % o, C["sel"] if i == idx else 0)
            put(scr, y0 + bh - 1, x0 + 3, " Up/Down + Enter    Esc = back ", C["warn"])
            scr.refresh()
            k = scr.getch()
            if k == curses.KEY_UP:
                idx = (idx - 1) % len(options)
            elif k == curses.KEY_DOWN:
                idx = (idx + 1) % len(options)
            elif k in (10, 13, curses.KEY_ENTER):
                return idx
            elif k == 27:
                return None
    finally:
        scr.timeout(1000)


# ------------------------------------------------------------------ actions
def restart_sensor():
    sh(["systemctl", "restart", "--no-block", SERVICE])


def web_url(st):
    ip = st.d.get("ip", "").split("/")[0]
    return "https://%s:8080" % ip if ip else "https://<no address yet>:8080"


def act_network(scr, st):
    c = load_net()
    k = choose(scr, "Management port address (%s)" % (mgmt_port(c) or "no port"), ["Automatic (DHCP)", "Fixed IP address"], 0 if c["mode"] == "dhcp" else 1)
    if k is None:
        return
    if k == 0:
        c["mode"] = "dhcp"
    else:
        ip = ask(scr, "Fixed IP", "IP address with prefix, for example 192.168.1.50/24", c["ip_cidr"])
        if not ip:
            return
        try:
            ipaddress.ip_interface(ip)
        except ValueError:
            dialog(scr, "Not valid", ["%r is not an IP address with prefix. Example: 192.168.1.50/24" % ip])
            return
        gw = ask(scr, "Fixed IP", "Gateway (router) address, empty = none", c["gateway"])
        if gw is None:
            return
        dns = ask(scr, "Fixed IP", "DNS server(s), comma separated, empty = none", c["dns"] or "8.8.8.8")
        if dns is None:
            return
        c.update(mode="static", ip_cidr=ip, gateway=gw, dns=dns)
    save_net(c)
    out = []
    dialog(scr, "Applying", ["Applying network settings, please wait..."], wait=False)
    apply_net(out.append, wait=20)
    st.collect()
    dialog(scr, "Network", out + ["", "Settings last until the next restart of this sensor. For a permanent address, build the sensor in central with the address filled in."])


def act_ports(scr, st):
    p = nics()
    if not p:
        dialog(scr, "Ports", ["No network port found."])
        return
    c = load_net()
    cur = mgmt_port(c)
    k = choose(scr, "Which port is the MANAGEMENT port? (all others = SPAN/capture)", ["%s%s" % (n, "   (now management)" if n == cur else "") for n in p], p.index(cur))
    if k is None:
        return
    c["mgmt"] = p[k]
    save_net(c)
    dialog(scr, "Applying", ["Applying, please wait..."], wait=False)
    out = []
    apply_net(out.append, wait=20)
    restart_sensor()
    st.collect()
    dialog(scr, "Ports", out + ["", "The sensor is restarting to use the new roles."])


def act_sra(scr, st):
    """Remote access (SRA) port: choose the port only. Its address / VLANs are set in "SRA address / VLANs"."""
    m = sra()
    mg = mgmt_port()
    cands = [n for n in nics() if n != mg]
    if not cands:
        dialog(scr, "Remote access (SRA)", ["No free port. The remote-access port needs its own network port:", "in VMware / Hyper-V / VirtualBox add one more network adapter to the VM."])
        return
    cur = m.load()
    items = ["%s%s" % (n, "   (now the remote-access port)" if n == cur.get("port") else "") for n in cands] + ["Switch the remote-access port OFF"]
    k = choose(scr, "Which port is the REMOTE ACCESS (SRA) port?", items, cands.index(cur["port"]) if cur.get("port") in cands else 0)
    if k is None:
        return
    if k == len(cands):
        m.clear_cfg()
    elif cur.get("port") != cands[k]:
        m.save({"port": cands[k], "vlan": 0, "ip_cidr": "", "gateway": "", "extra": []})
    dialog(scr, "Applying", ["Applying, please wait..."], wait=False)
    out = []
    apply_net(out.append, wait=20)
    restart_sensor()
    st.collect()
    dialog(scr, "Remote access (SRA)", out + ["", "Next: use \"SRA address / VLANs\" to give this port its address."])


def act_sra_addr(scr, st):
    """Address of the SRA port: main network (IP, VLAN, gateway) and extra VLAN networks."""
    m = sra()
    cur = m.load()
    if not cur.get("port"):
        dialog(scr, "SRA address", ["First choose the remote-access port with \"Remote access (SRA)\"."])
        return
    opts = ["Main address (IP, VLAN, gateway)", "Add a VLAN network (sensor gets an address inside that VLAN)", "Remove all VLAN networks", "Remove the address (port stays reserved)"]
    k = choose(scr, "SRA port %s - what do you want to set?" % cur["port"], opts, 0)
    if k is None:
        return
    c = dict(cur)
    c["extra"] = list(c.get("extra") or [])
    if k == 0:
        v = ask(scr, "Remote access (SRA)", "VLAN number for this port (1-4094), empty = no VLAN", str(cur.get("vlan") or ""))
        if v is None:
            return
        ip = ask(scr, "Remote access (SRA)", "Fixed IP address with prefix, for example 10.20.0.5/24", cur.get("ip_cidr", ""))
        if not ip:
            return
        gw = ask(scr, "Remote access (SRA)", "Gateway inside that network, empty = none (devices on the same network)", cur.get("gateway", ""))
        if gw is None:
            return
        c.update(vlan=int(v) if v.strip().isdigit() else 0, ip_cidr=ip.strip(), gateway=gw.strip())
    elif k == 1:
        if not c.get("ip_cidr"):
            dialog(scr, "SRA address", ["Give the main address first."])
            return
        v = ask(scr, "Remote access (SRA)", "VLAN number of the devices (1-4094)", "")
        if not v or not v.strip().isdigit():
            return
        ip = ask(scr, "Remote access (SRA)", "Address of the sensor inside that VLAN, for example 10.30.0.5/24", "")
        if not ip:
            return
        c["extra"] = [e for e in c["extra"] if str(e.get("vlan")) != v.strip()] + [{"vlan": int(v), "ip_cidr": ip.strip()}]
    elif k == 2:
        c["extra"] = []
    else:
        c.update(vlan=0, ip_cidr="", gateway="", extra=[])
    skip = (c["port"], m.ifname(c)) + tuple("sra%s" % e.get("vlan") for e in c["extra"])
    ok, why = m.validate(c, m.other_addresses(skip=skip))
    if not ok:
        dialog(scr, "Not valid", [why])
        return
    m.save(c)
    dialog(scr, "Applying", ["Applying, please wait..."], wait=False)
    out = []
    apply_net(out.append, wait=20)
    restart_sensor()
    st.collect()
    dialog(scr, "Remote access (SRA)", out + ["", "Engineer sessions from central leave through this port only.", "Devices in each VLAN you added are reached through the sensor's address in that VLAN."])


def act_sitenet(scr, st):
    """DNS and time server of THIS site (different for every site)."""
    m = sra()
    cur = m.sitenet_load()
    dns = ask(scr, "DNS server", "DNS server(s) of this site, comma separated (empty = what DHCP gives)", cur.get("dns", ""))
    if dns is None:
        return
    ntp = ask(scr, "Time server (NTP)", "Time server(s) of this site, e.g. 192.168.1.1 or pool.ntp.org (empty = default)", cur.get("ntp", ""))
    if ntp is None:
        return
    ok, why = m.sitenet_save(dns, ntp)
    if not ok:
        dialog(scr, "Not valid", [why])
        return
    dialog(scr, "DNS / time server", ["Saved."] + (m.sitenet_apply() or []))
    st.collect()


def write_override(site, central, token):
    lines = ["SITE=%s" % shlex.quote(site), "CENTRAL=%s" % shlex.quote(central), "TOKEN=%s" % shlex.quote(token)]
    try:        # keep the line that restores a saved update at boot
        lines += [l for l in open(OVERRIDE).read().splitlines() if "otsense-persist" in l]
    except OSError:
        pass
    write_private(OVERRIDE, "\n".join(lines) + "\n")


def act_central(scr, st):
    s = read_json(SENSORJ)
    central = ask(scr, "Central server", "Web address of central, for example https://central.example.com", s.get("central", ""))
    if central is None:
        return
    if central and "://" not in central:
        central = "https://" + central
    token = ask(scr, "Central server", "Site token (copy it from central: Sites tab)", s.get("token", ""))
    if token is None:
        return
    site = ask(scr, "Central server", "Site name", s.get("site", "") or socket.gethostname())
    if site is None:
        return
    write_override(site, central, token)
    restart_sensor()
    dialog(scr, "Central server", ["Saved. The sensor is restarting and will connect to:", central, "", "Use 'Test connectivity' in the menu to check the link."])


def act_test(scr, st):
    dialog(scr, "Test connectivity", ["Testing, please wait (up to 30 seconds)..."], wait=False)
    st.collect()
    d = st.d
    out = []

    def line(ok, text):
        out.append("[ %s ] %s" % ({True: " OK ", False: "FAIL", None: " -- "}[ok], text))
    line(bool(d["ip"]), "Management port %s: %s" % (d["mgmt"] or "none", d["ip"] or "no address (check cable / VM network adapter / DHCP)"))
    if d["ip"]:
        line(bool(d["gw"]) and d["ping"] != "no reply" if d["gw"] else None, "Gateway %s: %s" % (d["gw"] or "none", d["ping"] or "not tested"))
    s = read_json(SENSORJ)
    if not s.get("central"):
        line(None, "Central address not set - use 'Central server' in the menu")
    else:
        try:
            sys.path.insert(0, D)
            import otsense
            steps, mode = otsense.test_central(s.get("central", ""), s.get("token", ""), s.get("cafile") or None, bool(s.get("insecure")), s.get("site", ""), timeout=6)
            for label, ok, detail in steps:
                line(ok, "%s: %s" % (label, detail))
        except Exception as e:
            line(False, "test could not run: %s" % e)
            dns, tcp = quick_central(s["central"])
            line(None, "DNS: %s   %s" % (dns, tcp))
    dialog(scr, "Test connectivity", out)


def act_ping(scr, st):
    host = ask(scr, "Ping", "Host name or IP to ping", st.d.get("gw") or "8.8.8.8")
    if not host:
        return
    if not re.match(r"^[A-Za-z0-9._:-]+$", host):
        dialog(scr, "Ping", ["Not a valid host name."])
        return
    dialog(scr, "Ping", ["Pinging %s ..." % host], wait=False)
    rc, o = sh(["ping", "-c", "4", "-W", "2", host], timeout=15)
    dialog(scr, "Ping %s" % host, o.splitlines() or ["no output"])


def act_password(scr, st):
    k = choose(scr, "Web page password", ["Show the web address and password", "Set a new password"])
    if k is None:
        return
    if k == 0:
        dialog(scr, "Sensor web page", ["Open this on any PC that can reach the sensor:", web_url(st), "", "Password: %s" % (st.d.get("pw") or "(not created yet - wait a minute)"), "",
                                       "The browser warns about the certificate once: Advanced > continue."])
        return
    pw = ask(scr, "New password", "New web password (at least 8 characters)", "", secret=False)
    if pw is None:
        return
    if len(pw) < 8:
        dialog(scr, "Password", ["Too short - use at least 8 characters."])
        return
    write_private(PWFILE, pw)
    restart_sensor()
    dialog(scr, "Password", ["New web password saved. The sensor is restarting."])


def act_restart(scr, st):
    restart_sensor()
    dialog(scr, "Sensor", ["The sensor service is restarting. It takes about 20 seconds."])


def act_rollback(scr, st):
    if choose(scr, "Undo the software update? (the previous sensor software and screen files come back)", ["No", "Yes, undo it"]) != 1:
        return
    rc, o = sh(["python3", os.path.join(os.environ.get("D", "/opt/otsense"), "otsense.py"), "rollback", "--state-dir", STATE], timeout=30)
    dialog(scr, "Undo software update", (o or "done").strip().splitlines()[-8:] + ["The sensor and this screen restart now."])


def act_log(scr, st):
    rc, o = sh(["journalctl", "-u", SERVICE, "-n", "60", "--no-pager", "-o", "cat"], timeout=10)
    if not o:
        o = (rd("/var/log/otsense-netapply.log") or "no log yet")
    dialog(scr, "Sensor log (last lines)", o.splitlines()[-80:])


def act_shell(scr, st):
    pw = ask(scr, "Shell", "Enter the web password to open a shell", "", secret=True)
    if pw is None:
        return
    if not st.d.get("pw") or pw != st.d["pw"]:
        dialog(scr, "Shell", ["Wrong password."])
        return
    curses.def_prog_mode()
    curses.endwin()
    os.system("clear; echo 'OT Sense shell - type exit to return to the menu'; /bin/bash -l")
    curses.reset_prog_mode()
    scr.clear()


def act_reboot(scr, st):
    if choose(scr, "Restart this sensor?", ["No", "Yes, restart now"]) == 1:
        sh(["systemctl", "reboot"])


def act_off(scr, st):
    if choose(scr, "Power off this sensor?", ["No", "Yes, power off now"]) == 1:
        sh(["systemctl", "poweroff"])


def act_graphical(scr, st):
    """leave the text screen; otsense-screen.sh then starts the graphical screen again"""
    if not (os.path.exists("/usr/bin/Xorg") and os.path.exists("/usr/bin/xinit")):
        dialog(scr, "Graphical screen", ["The graphical screen is not installed in this image."])
        return
    try:
        os.remove("/run/otsense/no-gui")
    except OSError:
        pass
    raise SystemExit(0)


ACTIONS = [("Network address", act_network), ("Ports (mgmt/SPAN)", act_ports), ("Remote access (SRA)", act_sra), ("SRA address / VLANs", act_sra_addr), ("DNS / Time server", act_sitenet), ("Central server", act_central),
           ("Test connectivity", act_test), ("Ping", act_ping), ("Web password", act_password), ("SSH on/off", act_ssh),
           ("Restart sensor", act_restart), ("Show log", act_log), ("Undo software update", act_rollback), ("Shell", act_shell),
           ("Graphical screen", act_graphical), ("Restart", act_reboot), ("Power off", act_off)]
COLS = 4


# ------------------------------------------------------------------ main screen
def draw(scr, st, sel):
    scr.erase()
    h, w = scr.getmaxyx()
    d = st.d
    bw = w - 2
    site = d["site"] or "not stamped"
    put(scr, 0, 1, "OT Sense Appliance, Site: %s" % site, C["head"] | curses.A_BOLD)
    t = time.strftime("%a %b %d %H:%M:%S UTC %Y", time.gmtime())
    put(scr, 0, max(1, w - len(t) - 2), t)
    y = 1
    nrows = len(ACTIONS) // COLS + (1 if len(ACTIONS) % COLS else 0)
    room = h - (2 + 7 + 7 + nrows + 2 + 2)          # lines left for port rows
    ports = d["ports"][:max(1, room)]
    box(scr, y, 1, len(ports) + 3 if ports else 3, bw, "Interfaces", C["box"])
    if not ports:
        put(scr, y + 1, 3, "No network port found - in VMware add a Network Adapter to the VM.", C["bad"])
        y += 3
    for i, p in enumerate(ports):
        x = tag(scr, y + 1 + i, 3, p["n"], C["ok"] if p["state"] == "up" else C["bad"])
        put(scr, y + 1 + i, x, "%-5s %-5s" % (p["role"], p["state"].upper()))
        if p["role"] == "MGMT":
            if p["ip"]:
                put(scr, y + 1 + i, x + 12, "ip: %s   gw: %s   ping: %s" % (p["ip"], d["gw"] or "-", d["ping"] or "-"))
            else:
                put(scr, y + 1 + i, x + 12, "waiting for an address (%s)..." % ("DHCP" if d.get("mode") != "static" else "fixed"), C["warn"])
        elif p["role"] == "SRA":
            v = (d.get("sra") or {}).get("vlan")
            put(scr, y + 1 + i, x + 12, "remote access  ip: %s%s%s" % (p["ip"] or (d.get("sra") or {}).get("ip_cidr", "") or "(no address yet - SRA address)", ("   VLAN %s" % v) if v else "", "".join("  +VLAN %s %s" % (e.get("vlan"), e.get("ip_cidr")) for e in ((d.get("sra") or {}).get("extra") or []))))
        else:
            put(scr, y + 1 + i, x + 12, "capture, no IP   rx packets: %s" % p["rx"])
        put(scr, y + 1 + i, w - 20, p.get("mac", ""))
    if ports:
        y += len(ports) + 3
    box(scr, y, 1, 7, bw, "Services", C["box"])
    act = d["active"]
    x = tag(scr, y + 1, 3, "Sensor", C["ok"] if act == "active" else C["bad"])
    put(scr, y + 1, x, ("Active" if act == "active" else "Not running (%s) - see Show log" % act) + (("   software v%s" % (d.get("cs") or {}).get("version")) if (d.get("cs") or {}).get("version") else ""), C["ok"] if act == "active" else C["bad"])
    x = tag(scr, y + 2, 3, "Web page", C["ok"] if d["ip"] else C["warn"])
    put(scr, y + 2, x, "%s" % web_url(st), curses.A_BOLD)
    cs = d.get("cs") or {}
    x = tag(scr, y + 3, 3, "Login", C["ok"])
    put(scr, y + 3, x, "user: otsense    password: %s    (web page, this shell, SSH - same as central Show login)" % (d["pw"] or "..."), curses.A_BOLD)
    ls, lt = link_state(d)
    x = tag(scr, y + 4, 3, "Central", C["ok"] if ls == "ok" else C["bad"] if ls == "down" else C["warn"])
    put(scr, y + 4, x, "%s %s" % (blink_dot(ls), lt), (C["ok"] if ls == "ok" else C["bad"] if ls == "down" else C["warn"]) | curses.A_BOLD)
    ssh_on = cs.get("ssh")
    x = tag(scr, y + 5, 3, "SSH", C["ok"] if ssh_on else C["warn"])
    put(scr, y + 5, x, "ON - port 22, user otsense" if ssh_on else "off (menu: SSH on/off, or central: Turn SSH on)")
    y += 7
    si = d.get("si") or {}
    mode = d.get("mode") or si.get("mode") or "dhcp"
    dns = sra().sitenet_load().get("dns") or si.get("dns") if (mode == "static" and si.get("dns")) else ", ".join(re.findall(r"^nameserver\s+(\S+)", rd("/etc/resolv.conf"), re.M)[:2])
    box(scr, y, 1, 7, bw, "Site (settings from central)", C["box"])
    put(scr, y + 1, 3, "Site name   : %s   (%s)" % (d["site"] or "not set", "stamped by central" if si.get("stamped") else "not stamped"))
    put(scr, y + 2, 3, "Central     : %s" % (d["central"] or "not set - choose 'Central server'"))
    put(scr, y + 3, 3, "Server      : DNS %s   HTTPS %s" % (d["dns"] or "-", d["tcp"] or "-"), C["ok"] if "reachable" in d["tcp"] else C["warn"])
    put(scr, y + 4, 3, "Sensor name : %s     IP: %s %s  gw %s  DNS %s" % ((cs.get("name") or si.get("hostname") or socket.gethostname()), "DHCP" if mode != "static" else "fixed", d["ip"] or "waiting...", d["gw"] or "-", dns or "-"))
    put(scr, y + 5, 3, "Time (NTP)  : %s   synchronised: %s" % ((sra().sitenet_load().get("ntp") or si.get("ntp") or "not set"), d.get("ntp_sync") or "?"))
    y += 7
    box(scr, y, 1, nrows + 2, bw, "Actions", C["box"])
    cw = (bw - 4) // COLS
    for i, (name, _) in enumerate(ACTIONS):
        r, c = divmod(i, COLS)
        label = "[ %s ]" % name
        put(scr, y + 1 + r, 3 + c * cw, label, C["sel"] if i == sel else curses.A_BOLD)
    put(scr, h - 1, 1, "Arrow keys + Enter.  G = graphical screen.  Everything changed here is applied at once.", C["warn"])
    scr.refresh()


def main(scr):
    colors()
    try:
        curses.curs_set(0)
    except curses.error:
        pass
    scr.keypad(True)
    scr.timeout(1000)
    st = Status()
    st.start()
    sel = 0
    while True:
        draw(scr, st, sel)
        k = scr.getch()
        if k == curses.KEY_LEFT:
            sel = max(0, sel - 1)
        elif k == curses.KEY_RIGHT:
            sel = min(len(ACTIONS) - 1, sel + 1)
        elif k == curses.KEY_UP:
            sel = sel - COLS if sel - COLS >= 0 else sel
        elif k == curses.KEY_DOWN:
            sel = sel + COLS if sel + COLS < len(ACTIONS) else sel
        elif k in (10, 13, curses.KEY_ENTER):
            try:
                ACTIONS[sel][1](scr, st)
            except Exception as e:
                dialog(scr, "Error", ["%s: %s" % (type(e).__name__, e)])
            st.collect()
        elif k in (ord('g'), ord('G')):
            act_graphical(scr, st)
        elif k == curses.KEY_RESIZE:
            scr.clear()


if __name__ == "__main__":
    if "--net" in sys.argv:
        ok = apply_net(lambda m: print("[otsense-net] " + m, flush=True))
        sys.exit(0)
    if "--ports" in sys.argv:
        p = nics()
        mg = mgmt_port()
        sp = sra_port(mg)
        print("MGMT=%s" % shlex.quote(mg))
        print("CAP=%s" % shlex.quote(",".join(x for x in p if x not in (mg, sp))))
        print("SRA=%s" % shlex.quote(sp))
        sys.exit(0)
    os.environ.setdefault("TERM", "linux")
    os.environ.setdefault("ESCDELAY", "50")
    while True:
        try:
            curses.wrapper(main)
        except KeyboardInterrupt:
            pass
        except Exception as e:
            sys.stderr.write("\nOT Sense console error: %s: %s\nrestarting in 3 seconds...\n" % (type(e).__name__, e))
            time.sleep(3)
