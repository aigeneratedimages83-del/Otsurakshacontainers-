#!/usr/bin/env bash
# Builds the ONE reusable sensor ISO (x86-64: VMware, Hyper-V, VirtualBox, Proxmox/KVM, laptops/PCs from USB).
# Run once, on Debian 12 or Ubuntu 22.04/24.04 with internet, as root:   sudo ./build-iso.sh /path/to/otsense-docker
# Result: ./images/otsense-sensor.iso  -> copy it into the "images" folder next to central.js. No tokens or passwords inside:
# central stamps site name, token and IP into a reserved 64 KB slot of this same file at every download.
# Inside: Debian 12 live system + python3 running the same otsense.py as your container (no Docker inside, so it is light: 2 vCPU / 2-4 GB RAM).
# NOTE: written without a build machine to test on. Run it once and read any error; boot the result in a test VM before using it.
set -euo pipefail
SRC="${1:-}"; [ -f "$SRC/otsense.py" ] || { echo "usage: sudo $0 /path/to/otsense-docker   (folder containing otsense.py)"; exit 1; }
SRC="$(readlink -f "$SRC")"; HERE="$(cd "$(dirname "$0")" && pwd)"; OUT="${OUT_DIR:-$HERE/images}"; W="$HERE/work-iso"
[ "$(id -u)" -eq 0 ] || { echo "run with sudo"; exit 1; }
apt-get update -qq; apt-get install -y -qq live-build debootstrap xorriso squashfs-tools python3 curl
rm -rf "$W"; mkdir -p "$W" "$OUT"; cd "$W"
lb config --distribution bookworm --architectures amd64 --archive-areas main --binary-images iso-hybrid \
  --bootloaders "syslinux,grub-efi" --debian-installer none --apt-indices false --apt-recommends false \
  --iso-volume OTSENSE --iso-application "OT Sense sensor" --memtest none --bootappend-live "boot=live components nomodeset"
# plug and play: boot the first entry by itself after 3 seconds (nobody has to press a key); only if this live-build version knows the option
if lb config --help 2>&1 | grep -q -- '--syslinux-timeout'; then lb config --syslinux-timeout 1; fi
if lb config --help 2>&1 | grep -q -- '--grub-timeout'; then lb config --grub-timeout 1; fi
cat > config/package-lists/otsense.list.chroot <<'EOL'
python3
openssl
iproute2
ethtool
tcpdump
ifupdown
isc-dhcp-client
ca-certificates
open-vm-tools
openssh-server
iputils-ping
systemd-timesyncd
e2fsprogs
xserver-xorg-core
xinit
xkb-data
x11-xkb-utils
xserver-xorg-video-fbdev
xserver-xorg-video-vesa
xserver-xorg-video-vmware
xserver-xorg-input-libinput
python3-tk
open-vm-tools-desktop
spice-vdagent
xclip
firefox-esr
fonts-dejavu-core
ncurses-base
ncurses-term
less
nano
EOL
mkdir -p config/includes.chroot/opt/otsense config/includes.chroot/etc/systemd/system config/includes.binary/otsense config/hooks/live
if [ -n "${CONTAINER_TAR:-}" ]; then       # container build: Docker + the sensor container are inside the ISO (works without internet)
  [ -f "$CONTAINER_TAR" ] || { echo "CONTAINER_TAR not found: $CONTAINER_TAR"; exit 1; }
  printf 'docker.io\niptables\n' >> config/package-lists/otsense.list.chroot
  cp "$CONTAINER_TAR" config/includes.chroot/opt/otsense/container-image.tar.gz; : > config/includes.chroot/opt/otsense/container.mode
fi
cp "$SRC/otsense.py" "$SRC/otsense_central.py" config/includes.chroot/opt/otsense/ 2>/dev/null || cp "$SRC/otsense.py" config/includes.chroot/opt/otsense/
cp "$HERE/iso/run-sensor.sh" "$HERE/iso/slot-read.py" "$HERE/iso/otsense-console.py" "$HERE/iso/otsense-hostapi.py" "$HERE/iso/otsense-gui.py" "$HERE/iso/otsense-screen.sh" "$HERE/iso/otsense-data.sh" "$HERE/iso/install-guacd.sh" "$HERE/iso/otsense-sra.py" config/includes.chroot/opt/otsense/
cp "$HERE/iso/otsense-sensor.service" "$HERE/iso/otsense-console.service" "$HERE/iso/otsense-data.service" config/includes.chroot/etc/systemd/system/
cat > config/hooks/live/0100-otsense.hook.chroot <<'HOOK'
#!/bin/sh
set -e
chmod +x /opt/otsense/*.sh /opt/otsense/*.py
# the console screen needs python's curses module: stop the build here if it is missing
python3 -c 'import curses'
python3 -c 'import tkinter'
systemctl enable otsense-sensor.service
systemctl enable otsense-console.service
systemctl enable otsense-data.service
# browser remote desktop (guacd): optional, never stops the build
bash /opt/otsense/install-guacd.sh || true
rm -f /opt/otsense/install-guacd.sh
mkdir -p /etc/guacamole; printf '[server]\nbind_host = 127.0.0.1\nbind_port = 4822\n' > /etc/guacamole/guacd.conf
# tty1 belongs to the OT Sense console screen (other consoles, Ctrl+Alt+F2, keep their normal login)
mkdir -p /etc/systemd/system
ln -sf /dev/null /etc/systemd/system/getty@tty1.service
systemctl disable ssh 2>/dev/null || true
# Docker is started by run-sensor.sh (its files go on the settings disk), not at boot
systemctl disable docker docker.socket 2>/dev/null || true
HOOK
# boot menu: start the first entry by itself after 3 seconds (the live-build option for this is not in every version, so also patch the menu files)
cat > config/hooks/live/0900-boot-timeout.hook.binary <<'HOOK'
#!/bin/sh
for f in binary/isolinux/isolinux.cfg binary/isolinux/menu.cfg binary/isolinux/live.cfg; do
  [ -f "$f" ] && sed -i -E 's/^([[:space:]]*timeout[[:space:]]+)[0-9]+/\110/' "$f"
done
[ -f binary/isolinux/isolinux.cfg ] && ! grep -qE '^[[:space:]]*timeout' binary/isolinux/isolinux.cfg && printf 'timeout 10\n' >> binary/isolinux/isolinux.cfg
for f in binary/boot/grub/grub.cfg binary/boot/grub/config.cfg; do
  [ -f "$f" ] && sed -i -E 's/^([[:space:]]*set timeout=).*/\11/' "$f"
done
exit 0
HOOK
mkdir -p config/hooks/normal; cp config/hooks/live/0900-boot-timeout.hook.binary config/hooks/normal/
chmod +x config/hooks/live/* config/hooks/normal/*
# the empty config slot: 16-byte marker + zeros, stored as a plain file in the ISO (NOT inside the compressed system) so central can overwrite it in place
python3 -c "open('config/includes.binary/otsense/slot.bin','wb').write(b'OTSENSE_SLOT_V1\n'+bytes(65536-16))"
lb build 2>&1 | tail -n 40
ISO="$(ls -1 live-image-amd64.hybrid.iso *.iso 2>/dev/null | head -1)"; [ -f "$ISO" ] || { echo "ISO was not produced - see messages above"; exit 1; }
# plug and play: make the boot menu start the first entry by itself after 3 seconds. Done on the finished ISO, so it works with every live-build version.
if command -v xorriso >/dev/null 2>&1; then
  P="$(mktemp -d)"
  xorriso -osirrox on -indev "$ISO" -extract /isolinux "$P/isolinux" >/dev/null 2>&1 || true
  xorriso -osirrox on -indev "$ISO" -extract /boot/grub "$P/grub" >/dev/null 2>&1 || true
  chmod -R u+w "$P" 2>/dev/null || true
  MAPS=()
  if [ -f "$P/isolinux/isolinux.cfg" ]; then
    C="$P/isolinux/isolinux.cfg"
    if grep -qiE '^[[:space:]]*timeout' "$C"; then sed -i -E 's/^[[:space:]]*[Tt][Ii][Mm][Ee][Oo][Uu][Tt][[:space:]]+[0-9]+/timeout 10/' "$C"; else echo "timeout 10" >> "$C"; fi
    grep -qiE '^[[:space:]]*prompt' "$C" && sed -i -E 's/^[[:space:]]*prompt[[:space:]]+.*/prompt 0/' "$C" || echo "prompt 0" >> "$C"
    FIRST="$(grep -hiE '^[[:space:]]*label[[:space:]]+' "$P/isolinux/live.cfg" 2>/dev/null | head -1 | awk '{print $2}')"
    grep -qi '^[[:space:]]*ontimeout' "$C" || { [ -n "$FIRST" ] && echo "ontimeout $FIRST" >> "$C"; } || true
    MAPS+=(-map "$C" /isolinux/isolinux.cfg)
  fi
  for G in $(grep -rlE '^[[:space:]]*set timeout=' "$P/grub" 2>/dev/null || true); do
    sed -i -E 's/^([[:space:]]*set timeout=).*/\11/' "$G"; MAPS+=(-map "$G" "/boot/grub/${G#$P/grub/}")
  done
  if [ "${#MAPS[@]}" -gt 0 ] && xorriso -indev "$ISO" -outdev "$ISO.new" -boot_image any replay "${MAPS[@]}" -commit >/dev/null 2>&1 && [ -s "$ISO.new" ]; then
    mv -f "$ISO.new" "$ISO"; echo "boot menu now starts by itself after 1 second"
  else rm -f "$ISO.new"; echo "WARNING: could not patch the boot menu timeout (the menu will wait for Enter)"; fi
fi
cp "$ISO" "$OUT/otsense-sensor.iso.part"
# self-check: exactly one slot marker must exist in the finished ISO (central refuses the file otherwise)
N="$(python3 - "$OUT/otsense-sensor.iso.part" <<'PY'
import sys
M=b"OTSENSE_SLOT_V1\n"; n=0; tail=b""
with open(sys.argv[1],"rb") as f:
    while True:
        c=f.read(8<<20)
        if not c: break
        b=tail+c; n+=b.count(M); tail=b[-15:]
print(n)
PY
)"
[ "$N" = 1 ] || { rm -f "$OUT/otsense-sensor.iso.part"; echo "SELF-CHECK FAILED: found $N config slots (expected 1)"; exit 1; }
mv -f "$OUT/otsense-sensor.iso.part" "$OUT/otsense-sensor.iso"; ls -lh "$OUT/otsense-sensor.iso"; echo "OK. Copy it to <central>/images/otsense-sensor.iso (or set IMAGE_DIR). Reuse it for every site."
