#!/usr/bin/env bash
# Builds the sensor ISO and then the OVA from it (used by central's Build button and docker-build.sh ova-amd64).
set -euo pipefail
SRC="${1:-}"; HERE="$(cd "$(dirname "$0")" && pwd)"; OUT="${OUT_DIR:-$HERE/images}"
bash "$HERE/build-iso.sh" "$SRC"
apt-get install -y -qq qemu-utils e2fsprogs
bash "$HERE/make-ova.sh" "$OUT/otsense-sensor.iso" "$OUT/otsense-sensor.ova"
