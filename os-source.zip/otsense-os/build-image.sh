#!/usr/bin/env bash
# OT Sense OS image builder.   sudo ./build-image.sh <amd64|arm64> /path/to/sensor-src [outdir]
#   amd64 -> otsense-sensor.img        raw disk, boots BIOS and UEFI: VMware/Hyper-V(gen 1 or 2)/VirtualBox/Proxmox/KVM, or write to a PC / mini-PC SSD or USB stick
#   arm64 -> otsense-sensor-rpi.img.xz Raspberry Pi 3 / 4 / 5 SD card (Raspberry Pi OS Lite + the same sensor recipe)
# Needs a Debian/Ubuntu build machine with internet and root (the GitHub workflow in .github/workflows does all this for you).
# NOT RUN by the author of this script (no build machine available): run it once, read any error, then test in a VM first.
set -euo pipefail
ARCH="${1:-}"; SRC="${2:-}"; OUT="${3:-$(pwd)/images}"
[ "$ARCH" = amd64 ] || [ "$ARCH" = arm64 ] || { echo "usage: sudo $0 <amd64|arm64> /path/to/sensor-src [outdir]"; exit 1; }
[ -f "$SRC/otsense.py" ] || { echo "sensor source not found: $SRC (needs otsense.py)"; exit 1; }
[ "$(id -u)" -eq 0 ] || { echo "run with sudo"; exit 1; }
SRC="$(readlink -f "$SRC")"; HERE="$(cd "$(dirname "$0")" && pwd)"; mkdir -p "$OUT"; OUT="$(readlink -f "$OUT")"
W="$(mktemp -d /var/tmp/otsense-build.XXXXXX)"; MNT="$W/mnt"; LOOP=""
cleanup() { set +e; for m in dev/pts dev proc sys run boot/efi boot/firmware ""; do mountpoint -q "$MNT/$m" && umount -l "$MNT/$m"; done
  [ -n "$LOOP" ] && losetup -d "$LOOP"; rm -rf "$W"; }
trap cleanup EXIT
mkdir -p "$MNT"
log() { echo; echo "=== $*"; }

install_overlay() {      # copy the OT Sense files into the mounted root file system
  mkdir -p "$MNT/opt/otsense"
  cp -a "$HERE/overlay/." "$MNT/"
  cp "$SRC/otsense.py" "$MNT/opt/otsense/"; [ -f "$SRC/otsense_central.py" ] && cp "$SRC/otsense_central.py" "$MNT/opt/otsense/" || true
  if [ -n "${CONTAINER_TAR:-}" ]; then      # container build: the sensor runs inside a Docker container that is already in the image (works without internet)
    [ -f "$CONTAINER_TAR" ] || { echo "CONTAINER_TAR not found: $CONTAINER_TAR"; exit 1; }
    cp "$CONTAINER_TAR" "$MNT/opt/otsense/container-image.tar.gz"; : > "$MNT/opt/otsense/container.mode"
  fi
  cp "$HERE/chroot-setup.sh" "$MNT/root/chroot-setup.sh"
  find "$MNT/opt/otsense" -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true      # bytecode left by the offline tests
}
in_chroot() {
  for m in dev proc sys run; do mkdir -p "$MNT/$m"; done
  mount --bind /dev "$MNT/dev"; mount -t devpts devpts "$MNT/dev/pts" 2>/dev/null || true
  mount -t proc proc "$MNT/proc"; mount -t sysfs sys "$MNT/sys"; mount -t tmpfs tmpfs "$MNT/run"
  cp /etc/resolv.conf "$MNT/etc/resolv.conf" 2>/dev/null || echo "nameserver 1.1.1.1" > "$MNT/etc/resolv.conf"
  chroot "$MNT" /bin/bash /root/chroot-setup.sh "$ARCH"
  rm -f "$MNT/root/chroot-setup.sh"; : > "$MNT/etc/resolv.conf"
  for m in dev/pts dev proc sys run; do umount -l "$MNT/$m"; done
}
blank_slot() { python3 -c "import sys; open(sys.argv[1],'wb').write(b'OTSENSE_SLOT_V1\n'+bytes(65536-16))" "$1"; }

if [ "$ARCH" = amd64 ]; then
  #################### x86-64: debootstrap Debian 12 into a raw disk
  apt-get update -qq; apt-get install -y -qq debootstrap dosfstools gdisk parted e2fsprogs xz-utils python3 debian-archive-keyring
  IMG="$W/otsense-sensor.img"; SIZE_MB="${DISK_MB:-$([ -n "${CONTAINER_TAR:-}" ] && echo 3200 || echo 2000)}"      # under 2 GiB (2048 MiB) so it fits a GitHub release asset
  log "disk $SIZE_MB MB: BIOS boot + UEFI + root"
  truncate -s "${SIZE_MB}M" "$IMG"
  sgdisk -Z "$IMG" >/dev/null
  sgdisk -n1:2048:+2M -t1:EF02 -c1:bios "$IMG" >/dev/null
  sgdisk -n2:0:+128M -t2:EF00 -c2:OTBOOT "$IMG" >/dev/null
  sgdisk -n3:0:0 -t3:8300 -c3:otroot "$IMG" >/dev/null
  LOOP="$(losetup --show -fP "$IMG")"; sleep 1
  mkfs.vfat -F32 -n OTBOOT "${LOOP}p2" >/dev/null; mkfs.ext4 -q -L otroot -O ^has_journal "${LOOP}p3"
  mount "${LOOP}p3" "$MNT"; mkdir -p "$MNT/boot/efi"; mount "${LOOP}p2" "$MNT/boot/efi"
  log "debootstrap Debian 12 (bookworm), 5-10 minutes"
  debootstrap --arch=amd64 --variant=minbase --components=main,non-free-firmware --include=linux-image-amd64,grub-pc-bin,grub-efi-amd64-bin,grub2-common,initramfs-tools,systemd-sysv,dbus,udev,kmod \
    bookworm "$MNT" http://deb.debian.org/debian
  cat > "$MNT/etc/apt/sources.list" <<'EOL'
deb http://deb.debian.org/debian bookworm main non-free-firmware
deb http://deb.debian.org/debian-security bookworm-security main non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main non-free-firmware
EOL
  printf 'LABEL=otroot / ext4 defaults,noatime,errors=remount-ro 0 1\nLABEL=OTBOOT /boot/efi vfat umask=0077,nofail 0 2\ntmpfs /tmp tmpfs defaults,nosuid,nodev,size=128m 0 0\n' > "$MNT/etc/fstab"
  echo otsense > "$MNT/etc/hostname"; printf '127.0.0.1 localhost\n127.0.1.1 otsense\n' > "$MNT/etc/hosts"
  install_overlay
  log "install packages + sensor in the image"
  in_chroot
  find "$MNT/opt/otsense" -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
  log "boot loader (BIOS and UEFI)"
  for m in dev proc sys; do mount --bind "/$m" "$MNT/$m"; done
  chroot "$MNT" grub-install --target=i386-pc --recheck --boot-directory=/boot "$LOOP" 2>&1 | tail -n 3
  chroot "$MNT" grub-install --target=x86_64-efi --removable --no-nvram --efi-directory=/boot/efi --boot-directory=/boot 2>&1 | tail -n 3
  for m in dev proc sys; do umount -l "$MNT/$m"; done
  # fixed boot menu (no probing of the build machine's devices): find the root file system by its label, so it boots on any hypervisor or PC
  mkdir -p "$MNT/boot/grub"
  cat > "$MNT/boot/grub/grub.cfg" <<'EOL'
set timeout=1
set default=0
insmod part_gpt
insmod ext2
menuentry "OT Sense sensor" {
  search --no-floppy --label --set=root otroot
  linux /vmlinuz root=LABEL=otroot ro quiet loglevel=3 net.ifnames=0 biosdevname=0
  initrd /initrd.img
}
EOL
  [ -e "$MNT/vmlinuz" ] && [ -e "$MNT/initrd.img" ] || { echo "kernel/initrd links missing in the image root"; exit 1; }
  blank_slot "$MNT/boot/efi/otsense-slot.bin"          # the 64 KB place where central writes the site settings
  printf 'OT Sense sensor. otsense-slot.bin = site settings written by central. Do not delete.\r\n' > "$MNT/boot/efi/README.TXT"
  sync; umount "$MNT/boot/efi"; umount "$MNT"; fsck.vfat -n "${LOOP}p2" >/dev/null || true; e2fsck -fn "${LOOP}p3" >/dev/null || true
  losetup -d "$LOOP"; LOOP=""
  python3 - "$IMG" <<'PY'      # self-check: exactly ONE slot marker (central refuses the file otherwise)
import sys
M=b"OTSENSE_SLOT_V1\n"; n=0; tail=b""
with open(sys.argv[1],"rb") as f:
    while True:
        c=f.read(8<<20)
        if not c: break
        b=tail+c; n+=b.count(M); tail=b[-15:]
print("slot markers found:", n)
sys.exit(0 if n==1 else 1)
PY
  mv "$IMG" "$OUT/otsense-sensor.img"
  [ -n "${CONTAINER_TAR:-}" ] && { gzip -f -6 "$OUT/otsense-sensor.img"; ls -lh "$OUT/otsense-sensor.img.gz"; } || ls -lh "$OUT/otsense-sensor.img"
  echo "OK. Copy otsense-sensor.img to the images folder of central (Sites > Base images > x86-64 ready-made disk)."
else
  #################### Raspberry Pi: Raspberry Pi OS Lite (64-bit) + the same recipe
  apt-get update -qq; apt-get install -y -qq qemu-user-static binfmt-support parted e2fsprogs dosfstools xz-utils curl python3
  [ "$(uname -m)" = aarch64 ] || update-binfmts --enable qemu-aarch64 2>/dev/null || true
  BASE_URL="${RPI_URL:-https://downloads.raspberrypi.com/raspios_lite_arm64_latest}"
  log "download Raspberry Pi OS Lite 64-bit"
  curl -fL -o "$W/base.img.xz" "$BASE_URL"; xz -dc "$W/base.img.xz" > "$W/pi.img"; rm -f "$W/base.img.xz"
  truncate -s +"${PI_EXTRA_MB:-$([ -n "${CONTAINER_TAR:-}" ] && echo 1500 || echo 700)}M" "$W/pi.img"; parted -s "$W/pi.img" resizepart 2 100%
  LOOP="$(losetup --show -fP "$W/pi.img")"; sleep 1
  e2fsck -fy "${LOOP}p2" >/dev/null || true; resize2fs "${LOOP}p2" >/dev/null
  mount "${LOOP}p2" "$MNT"; mkdir -p "$MNT/boot/firmware"; mount "${LOOP}p1" "$MNT/boot/firmware"
  install_overlay
  cp "$(command -v qemu-aarch64-static)" "$MNT/usr/bin/" 2>/dev/null || true
  log "install packages + sensor in the image (runs under emulation on a PC, 10-20 minutes)"
  in_chroot
  rm -f "$MNT/usr/bin/qemu-aarch64-static"
  cat > "$MNT/boot/firmware/OTSENSE-README.txt" <<'EOL'
OT Sense sensor (Raspberry Pi)
1. Download otsense-site-<name>.zip from central (Sites > Build a ready-to-install sensor > Raspberry Pi).
2. Copy the file otsense-slot.bin from that zip into THIS drive (the boot drive of the SD card). Eject, put the card in the Pi, power on.
3. Connect a monitor + keyboard to see the status screen. Wi-Fi = management, the Ethernet port = SPAN (mirror) port.
Without the file you can still do everything on the screen: W = Wi-Fi, C = Central settings, P = ports.
EOL
  sync; umount "$MNT/boot/firmware"; umount "$MNT"; fsck.vfat -n "${LOOP}p1" >/dev/null || true; losetup -d "$LOOP"; LOOP=""
  log "compress"
  xz -T0 -6 -c "$W/pi.img" > "$OUT/otsense-sensor-rpi.img.xz"; ls -lh "$OUT/otsense-sensor-rpi.img.xz"
  echo "OK. Write otsense-sensor-rpi.img.xz to the SD card with Raspberry Pi Imager (Use custom) or balenaEtcher."
fi
