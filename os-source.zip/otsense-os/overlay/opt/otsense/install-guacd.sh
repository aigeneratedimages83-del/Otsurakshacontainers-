#!/bin/bash
# Installs guacd (the browser remote-desktop service). Runs once while the image is built, inside the image.
# Debian 12 / Raspberry Pi OS 12 have no "guacd" package, so: try apt first, otherwise build Apache Guacamole server (RDP only) from source.
# This script NEVER fails the image build: without guacd, only the in-browser remote desktop is missing (the helper app still works).
set +e
export DEBIAN_FRONTEND=noninteractive
VER=1.5.5
have() { [ -x /usr/local/sbin/guacd ] || command -v guacd >/dev/null 2>&1; }
if apt-get install -y -qq --no-install-recommends guacd libguac-client-rdp0 >/dev/null 2>&1 && have; then echo "[guacd] installed from apt"; exit 0; fi
echo "[guacd] not in apt - building guacamole-server $VER from source (RDP only)"
DEV="build-essential autoconf automake libtool pkg-config curl ca-certificates libcairo2-dev libjpeg62-turbo-dev libpng-dev uuid-dev libssl-dev libfreerdp-dev libwinpr2-dev"
apt-get update -qq >/dev/null 2>&1
if ! apt-get install -y -qq --no-install-recommends $DEV; then echo "[guacd] WARNING: build tools did not install - browser remote desktop will not be in this image"; exit 0; fi
W="$(mktemp -d)"; cd "$W" || exit 0
if curl -fsSL "https://archive.apache.org/dist/guacamole/$VER/source/guacamole-server-$VER.tar.gz" -o gs.tar.gz && tar -xzf gs.tar.gz && cd "guacamole-server-$VER"; then
  if ./configure --with-init-dir=/etc/init.d --without-ssh --without-telnet --without-vnc --without-kubernetes --without-pulse --without-vorbis --without-webp --without-pango --disable-guacenc --disable-guaclog >/tmp/guac-configure.log 2>&1 \
     && make -j"$(nproc)" >/tmp/guac-make.log 2>&1 && make install >/dev/null 2>&1; then
    ldconfig
    cat > /etc/systemd/system/guacd.service <<'UNIT'
[Unit]
Description=Guacamole remote desktop service (this sensor only)
After=network.target

[Service]
ExecStart=/usr/local/sbin/guacd -f -b 127.0.0.1 -l 4822
User=nobody
Restart=always

[Install]
WantedBy=multi-user.target
UNIT
    systemctl enable guacd.service >/dev/null 2>&1
    echo "[guacd] built and installed"
  else
    echo "[guacd] WARNING: the build failed - last lines:"; tail -n 15 /tmp/guac-configure.log /tmp/guac-make.log 2>/dev/null
  fi
else
  echo "[guacd] WARNING: could not download the source"
fi
cd /; rm -rf "$W" /tmp/guac-*.log
apt-get purge -y -qq build-essential autoconf automake libtool >/dev/null 2>&1; apt-get autoremove -y -qq >/dev/null 2>&1
have && echo "[guacd] ready" || echo "[guacd] NOT installed"
exit 0
