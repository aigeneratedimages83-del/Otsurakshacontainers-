#!/usr/bin/env python3
"""OT Sense - host helper for the sensor WEB PAGE.

Everything the sensor screen (graphical / text) can do on the machine itself - network address, management port, remote-access (SRA) port and VLANs,
SSH on/off, log, a set of diagnostic commands, restart / power off - is done here, so the sensor web page can offer the same.
It runs as root ON THE HOST (directly, or through nsenter when the sensor itself runs in a container) and talks JSON:

    echo '{"port": "ens35"}' | otsense-hostapi.py sra_set        ->  {"ok": true, "message": "..."}

Settings are kept in the same files as the screens use (net.json, sra.json ...), so screen and web page always show the same thing.
Changes that can cut the connection are saved first and applied a moment later in the background, so the answer still reaches the browser.
"""
import importlib.util, ipaddress, json, os, re, shutil, socket, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
os.environ.setdefault("D", HERE)
os.environ.setdefault("STATE", "/var/lib/otsense")
os.environ.setdefault("RUN", "/run/otsense")
D, STATE, RUN = os.environ["D"], os.environ["STATE"], os.environ["RUN"]
SERVICE = "otsense-sensor"


def _mod(name, fn):
    p = os.path.join(D, fn)
    if not os.path.exists(p):
        return None
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


otc = _mod("otc", "otsense-console.py")
HAS_NET = bool(otc and hasattr(otc, "load_net") and hasattr(otc, "apply_net"))


def sh(cmd, timeout=20):
    try:
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, timeout=timeout)
        return r.returncode, (r.stdout or "").strip()
    except subprocess.TimeoutExpired:
        return 124, "(stopped after %d seconds)" % timeout
    except Exception as e:      # noqa
        return 1, str(e)


def ssh_up():
    try:
        with socket.create_connection(("127.0.0.1", 22), timeout=1):
            return True
    except OSError:
        return False


def later(job, data=None, delay=2.0):
    """run a slow / connection-breaking job after this process has answered"""
    subprocess.Popen([sys.executable, os.path.abspath(__file__), "_bg", job, json.dumps(data or {}), str(delay)],
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def a_info(d):
    r = {"ok": True, "hostname": socket.gethostname(), "ssh": ssh_up(), "net_settings": HAS_NET, "service": SERVICE}
    try:
        r["uptime"] = int(float(open("/proc/uptime").read().split()[0]))
    except Exception:       # noqa
        pass
    if HAS_NET:
        r["net"] = otc.load_net()
        r["mgmt"] = otc.mgmt_port()
        r["ports"] = otc.nics()
    try:
        m = otc.sra() if HAS_NET else _mod("otsra", "otsense-sra.py")
        r["sra"] = m.load()
        r["sra_ifname"] = m.ifname(r["sra"]) if r["sra"].get("port") else ""
    except Exception:       # noqa
        r["sra"] = {}
    return r


def _ipv4(txt, what, prefix=False):
    try:
        if prefix and "/" not in txt:
            raise ValueError("no prefix")
        x = ipaddress.ip_interface(txt) if prefix else ipaddress.ip_address(txt)
        if prefix and x.network.prefixlen > 30:
            raise ValueError("prefix")
    except ValueError:
        raise ValueError("%s is not valid." % what)
    if x.version != 4:
        raise ValueError("%s must be an IPv4 address." % what)
    return x


def a_net_set(d):
    if not HAS_NET:
        return {"ok": False, "error": "this image keeps its network address in the build settings (central > Sites > Build); it cannot be changed here"}
    c = otc.load_net()
    mode = str(d.get("mode", "dhcp"))
    if mode == "dhcp":
        c.update(mode="dhcp")
    elif mode == "static":
        ip = str(d.get("ip_cidr", "")).strip()
        _ipv4(ip, "The IP address (like 192.168.1.50/24)", prefix=True)
        gw = str(d.get("gateway", "")).strip()
        if gw:
            _ipv4(gw, "The gateway")
        dns = ",".join(x.strip() for x in str(d.get("dns", "")).replace(";", ",").split(",") if x.strip())
        for x in dns.split(","):
            if x:
                _ipv4(x, "The DNS server %s" % x)
        c.update(mode="static", ip_cidr=ip, gateway=gw, dns=dns)
    else:
        return {"ok": False, "error": "mode must be dhcp or static"}
    otc.save_net(c)
    later("apply", {"restart": False})
    return {"ok": True, "message": "Saved. The address is applied in a moment - if you are connected to this page through this port the page will reconnect on the new address."}


def a_mgmt_set(d):
    if not HAS_NET:
        return {"ok": False, "error": "not available on this image"}
    p = str(d.get("port", ""))
    if p not in otc.nics():
        return {"ok": False, "error": "%r is not a network port of this sensor" % p}
    c = otc.load_net()
    c["mgmt"] = p
    otc.save_net(c)
    later("apply", {"restart": True})
    return {"ok": True, "message": "Management port set to %s. The sensor restarts to use the new roles (about 30 seconds)." % p}


def a_sra_set(d):
    """Remote-access (SRA) port: port + main address / VLAN + extra VLAN networks. Empty port = switch it off."""
    m = otc.sra() if HAS_NET else _mod("otsra", "otsense-sra.py")
    if m is None:
        return {"ok": False, "error": "remote access (SRA) is not part of this image"}
    port = str(d.get("port", "")).strip()
    if not port:
        m.clear_cfg()
        later("apply", {"restart": True})
        return {"ok": True, "message": "Remote-access port switched off."}
    mg = otc.mgmt_port() if HAS_NET else ""
    wired = otc.nics() if HAS_NET else [port]
    if port not in wired or port == mg:
        return {"ok": False, "error": "%s cannot be the remote-access port (it must be a wired port that is not the management port)." % port}
    c = {"port": port, "vlan": 0, "ip_cidr": "", "gateway": "", "extra": []}
    cur = m.load()
    if cur.get("port") == port:
        c.update({k: cur[k] for k in ("vlan", "ip_cidr", "gateway", "extra") if k in cur})
    for k in ("vlan", "ip_cidr", "gateway"):
        if k in d:
            c[k] = int(d[k] or 0) if k == "vlan" else str(d[k] or "").strip()
    if "extra" in d:
        c["extra"] = [{"vlan": int(e.get("vlan") or 0), "ip_cidr": str(e.get("ip_cidr", "")).strip()} for e in (d.get("extra") or []) if isinstance(e, dict)]
    skip = (c["port"], m.ifname(c)) + tuple("sra%s" % e.get("vlan") for e in c["extra"])
    ok, why = m.validate(c, m.other_addresses(skip=skip))
    if not ok:
        return {"ok": False, "error": why}
    m.save(c)
    later("apply", {"restart": True})
    return {"ok": True, "message": "Saved. The remote-access port is configured in a moment; engineer sessions from central leave through it only."}


def ssh_allow_login():
    """Make sure SSH accepts the password of user otsense (the images may ship sshd with passwords off = "server sent: publickey"), that the
    user exists and has the same password as the sensor web page, and that the SFTP part (WinSCP) is on."""
    try:
        os.makedirs("/etc/ssh/sshd_config.d", exist_ok=True)
        with open("/etc/ssh/sshd_config.d/00-otsense.conf", "w") as f:
            f.write("# written by OT Sense: password login for user otsense (same password as the sensor page)\n"
                    "PasswordAuthentication yes\nKbdInteractiveAuthentication yes\nUsePAM yes\nPermitRootLogin no\n")
        try:
            txt = open("/etc/ssh/sshd_config").read()
        except OSError:
            txt = ""
        if "sshd_config.d" not in txt:
            with open("/etc/ssh/sshd_config", "a") as f:
                f.write("\nInclude /etc/ssh/sshd_config.d/*.conf\n")
        subprocess.run(["sed", "-i", "-E", "s/^[[:space:]]*PasswordAuthentication[[:space:]]+no/PasswordAuthentication yes/I", "/etc/ssh/sshd_config"], capture_output=True, timeout=10)
        if "sftp" not in txt.lower():
            with open("/etc/ssh/sshd_config.d/10-otsense-sftp.conf", "w") as f:
                f.write("Subsystem sftp internal-sftp\n")
    except OSError:
        pass
    try:
        pw = ""
        for pth in (os.path.join(os.environ.get("STATE", "/var/lib/otsense"), "ui-password"), os.path.join(os.environ.get("RUN", "/run/otsense"), "ui-password")):
            try:
                pw = open(pth).read().strip()
            except OSError:
                pw = ""
            if pw:
                break
        if subprocess.run(["id", "otsense"], capture_output=True).returncode != 0:
            subprocess.run(["useradd", "-m", "-s", "/bin/bash", "-G", "sudo", "otsense"], capture_output=True, timeout=20)
        if pw and "\n" not in pw:
            subprocess.run(["chpasswd"], input="otsense:%s\n" % pw, universal_newlines=True, capture_output=True, timeout=20)
    except (OSError, subprocess.SubprocessError):
        pass


def _ssh_start():
    ssh_allow_login()
    os.makedirs("/run/sshd", exist_ok=True)
    subprocess.run(["ssh-keygen", "-A"], capture_output=True, timeout=60)
    subprocess.run(["systemctl", "unmask", "ssh"], capture_output=True, timeout=10)
    r = subprocess.run(["systemctl", "enable", "--now", "ssh"], capture_output=True, universal_newlines=True, timeout=40)
    subprocess.run(["systemctl", "reload-or-restart", "ssh"], capture_output=True, timeout=20)
    for _ in range(8):
        if ssh_up():
            return True, "SSH answers on port 22."
        time.sleep(0.5)
    return False, ((r.stderr or r.stdout or "").strip() or "SSH did not start.")[-300:]


def a_ssh(d):
    if d.get("on"):
        ok, why = _ssh_start()
        return {"ok": ok, "ssh": ssh_up(), "message": why} if ok else {"ok": False, "error": why}
    subprocess.run(["systemctl", "disable", "--now", "ssh"], capture_output=True, timeout=40)
    return {"ok": True, "ssh": ssh_up(), "message": "SSH is off."}


def a_log(d):
    n = max(10, min(500, int(d.get("n") or 120)))
    rc, o = sh(["journalctl", "-u", SERVICE, "-n", str(n), "--no-pager", "-o", "cat"], timeout=15)
    return {"ok": True, "text": o or "no log yet"}


HOSTRE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$")
CMDS = {      # a fixed list: the web page never runs free-form commands as root
    "ip_addr": (["ip", "-br", "addr"], "IP addresses of all ports"),
    "ip_link": (["ip", "-s", "link"], "Port counters (packets, errors, drops)"),
    "ip_route": (["ip", "route"], "Routes"),
    "ip_rule": (["ip", "rule"], "Routing rules (remote-access port)"),
    "listen": (["ss", "-ltnup"], "Listening ports"),
    "ntp": (["timedatectl"], "Time and NTP status"),
    "df": (["df", "-h"], "Disk space"),
    "mem": (["free", "-m"], "Memory"),
    "failed": (["systemctl", "--no-pager", "--failed"], "Failed services"),
    "sensor": (["systemctl", "status", SERVICE, "--no-pager", "-n", "20"], "Sensor service status"),
    "ssh_status": (["systemctl", "status", "ssh", "--no-pager", "-n", "12"], "SSH service status"),
    "docker": (["docker", "ps", "-a"], "Containers"),
    "os": (["cat", "/etc/os-release"], "Operating system"),
    "ping": (None, "Ping an address (needs a host)"),
    "lookup": (None, "DNS lookup (needs a host name)"),
}


def a_cmd(d):
    name = str(d.get("name", ""))
    if name not in CMDS:
        return {"ok": False, "error": "unknown command"}
    argv = CMDS[name][0]
    if name in ("ping", "lookup"):
        h = str(d.get("arg", "")).strip()
        if not HOSTRE.match(h):
            return {"ok": False, "error": "give a host name or IP address"}
        argv = ["ping", "-c", "4", "-W", "2", h] if name == "ping" else ["getent", "hosts", h]
    rc, o = sh(argv, timeout=30)
    if name == "lookup" and not o:
        o = "no answer for %s" % h
    return {"ok": True, "text": o or "(no output)"}


def a_commands(d):
    return {"ok": True, "commands": [{"name": k, "label": v[1], "arg": k in ("ping", "lookup")} for k, v in CMDS.items()]}


def a_restart_sensor(d):
    later("restart", {}, 1.5)
    return {"ok": True, "message": "The sensor restarts now (about 30 seconds)."}


def a_reboot(d):
    later("reboot", {}, 2.0)
    return {"ok": True, "message": "This machine restarts now."}


def a_poweroff(d):
    later("poweroff", {}, 2.0)
    return {"ok": True, "message": "This machine powers off now."}


def bg(job, d, delay):
    time.sleep(delay)
    if job == "apply" and HAS_NET:
        otc.apply_net(lambda s: None, wait=20)
        if d.get("restart"):
            otc.restart_sensor()
    elif job == "restart":
        sh(["systemctl", "restart", "--no-block", SERVICE])
    elif job == "reboot":
        sh(["systemctl", "reboot"])
    elif job == "poweroff":
        sh(["systemctl", "poweroff"])


ACTIONS = {k[2:]: v for k, v in list(globals().items()) if k.startswith("a_") and callable(v)}


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"ok": False, "error": "usage: otsense-hostapi.py <action>  (JSON on stdin)"}))
        return 2
    act = sys.argv[1]
    if act == "_bg":
        bg(sys.argv[2], json.loads(sys.argv[3] or "{}"), float(sys.argv[4]) if len(sys.argv) > 4 else 2.0)
        return 0
    try:
        raw = sys.stdin.read() if not sys.stdin.isatty() else ""
        data = json.loads(raw) if raw.strip() else {}
        fn = ACTIONS.get(act)
        if not fn:
            out = {"ok": False, "error": "unknown action"}
        else:
            out = fn(data if isinstance(data, dict) else {})
    except ValueError as e:
        out = {"ok": False, "error": str(e)}
    except Exception as e:      # noqa
        out = {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}
    print(json.dumps(out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
