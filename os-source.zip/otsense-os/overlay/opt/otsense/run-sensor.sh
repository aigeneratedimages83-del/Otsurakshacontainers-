#!/bin/bash
# OT Sense OS - starts the sensor (otsense-sensor.service). Reads /run/otsense/env written by otsense-prep.py.
# Test:  DRY=1 ENV=./env STATE=./state ./run-sensor.sh
set -u
DRY="${DRY:-0}"; ENV="${ENV:-/run/otsense/env}"; STATE="${STATE:-/var/lib/otsense}"; D="${D:-/opt/otsense}"
run() { if [ "$DRY" = 1 ]; then echo "+ $*"; else "$@"; fi; }
log() { echo "[otsense] $*"; }
# shellcheck disable=SC1090
. "$ENV" || { log "no $ENV - otsense-prep did not run"; exit 1; }
mkdir -p "$STATE"

# SPAN / capture ports: no IP, no IPv6 chatter, promiscuous, offloads off (so the sensor sees real frames, not merged ones)
for c in $(echo "${CAP:-}" | tr ',' ' '); do
  [ -e "/sys/class/net/$c" ] || [ "$DRY" = 1 ] || { log "capture port $c not present"; continue; }
  run sysctl -qw "net.ipv6.conf.$c.disable_ipv6=1" 2>/dev/null
  run ip addr flush dev "$c"
  run ip link set "$c" up promisc on
  run ethtool -K "$c" gro off lro off gso off tso off 2>/dev/null
done

# Remote-access (SRA) port: own IP / VLAN, used only for the engineer sessions started from central (settings: console screen > Remote access port).
# Runs every time so that a port that was switched off loses its rules again. Writes $RUN/sra.env (OTSENSE_SRA_IP) which the sensor reads.
OTS_STATE="$STATE" OTS_RUN="$(dirname "$ENV")" OTS_DRY="$DRY" python3 "$D/otsense-sra.py" apply || log "remote-access (SRA) port not applied (see message above)"
OTS_STATE="$STATE" OTS_DRY="$DRY" python3 "$D/otsense-sra.py" sitenet || true   # DNS / time server entered on the sensor
if [ -f "$(dirname "$ENV")/sra.env" ]; then set -a; . "$(dirname "$ENV")/sra.env"; set +a; fi

# ---- the sensor program runs INSIDE a container (images built with the container option carry Docker + the sensor container) ----
# If anything about the container does not work (Docker will not start, image missing, container stops within 30 s) the program is started directly
# as before, so the sensor never loses its connection to central because of the container. touch $STATE/no-container = always run directly.
run_in_container() {
  [ "$DRY" = 1 ] && return 1
  [ -f "$D/container.mode" ] && [ -f "$D/container-image.tar.gz" ] && command -v docker >/dev/null 2>&1 || return 1
  [ -e "$STATE/no-container" ] && return 1
  if [ -n "${CT_LIVE:-}" ]; then          # live ISO / OVA: the system is in memory, so Docker keeps its files on the settings disk (or in RAM without one)
    DR=/run/docker-data; mountpoint -q "$STATE" && DR="$STATE/docker"
    mkdir -p "$DR" /etc/docker; printf '{"data-root": "%s"}\n' "$DR" > /etc/docker/daemon.json
  fi
  systemctl restart docker >/dev/null 2>&1 || return 1
  local i; for i in $(seq 1 40); do docker info >/dev/null 2>&1 && break; sleep 1; done
  docker info >/dev/null 2>&1 || return 1
  docker image inspect otsense-sensor:current >/dev/null 2>&1 || docker load -i "$D/container-image.tar.gz" >/dev/null 2>&1 || return 1
  docker image inspect otsense-sensor:current >/dev/null 2>&1 || docker tag "$(docker image ls -q | head -1)" otsense-sensor:current 2>/dev/null || return 1
  docker rm -f otsense-sensor >/dev/null 2>&1
  local t0 rc R; t0=$(date +%s); R="${RUN:-$(dirname "${ENV:-/run/otsense/env}")}"
  log "starting the sensor inside its container"
  docker run --rm --name otsense-sensor --network host --privileged --pid=host --stop-timeout 10 \
    -v "$STATE":/data -v "$R":"$R" -e RUN="$R" -e OTSENSE_HOSTCTL=1 -e OTSENSE_NETAPPLY=0 \
    -v /etc/ssh:/etc/ssh -v /etc/resolv.conf:/etc/resolv.conf \
    ${OTSENSE_SRA_IP:+-e OTSENSE_SRA_IP="$OTSENSE_SRA_IP"} otsense-sensor:current sensor "$@"
  rc=$?
  if [ $(( $(date +%s) - t0 )) -lt 30 ]; then log "the sensor container did not stay up (exit $rc): running the program directly"; return 1; fi
  exit $rc
}

ARGS=(appliance --state-dir "$STATE")
if [ "${CONFIGURED:-0}" = 1 ]; then
  CONF=(appliance --state-dir "$STATE" --configure-only --site "$SITE" --central "$CENTRAL" --token "$TOKEN" --cafile "$CAFILE")
  [ -n "${CAP:-}" ] && CONF+=(--iface "$CAP")
  [ -n "${MGMT:-}" ] && CONF+=(--mgmt-iface "$MGMT")
  [ -n "${SCAN:-}" ] && CONF+=(--scan "$SCAN")
  CONF+=(--ui-password "$WEBPW")
  run python3 "$D/otsense.py" "${CONF[@]}" || log "could not write the settings (see message above)"
else
  log "no central address / token yet: use the console screen (C = Central settings) or the web page, Setup"
  # still tell the sensor which ports to use, so the web page shows them
  CONF=(appliance --state-dir "$STATE" --configure-only)
  [ -n "${CAP:-}" ] && CONF+=(--iface "$CAP")
  [ -n "${MGMT:-}" ] && CONF+=(--mgmt-iface "$MGMT")
  run python3 "$D/otsense.py" "${CONF[@]}" --ui-password "$WEBPW" || true
fi
ARGS+=(--ui-password "$WEBPW")
run_in_container --ui-password "$WEBPW" || true
run exec python3 "$D/otsense.py" "${ARGS[@]}"
