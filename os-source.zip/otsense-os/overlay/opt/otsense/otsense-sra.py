#!/usr/bin/env python3
"""OT Sense - Secure Remote Access (SRA) port.

One wired port (optionally on its own VLAN) is reserved for the remote-access sessions that engineers start from central.
It has its own fixed IP address and never carries capture traffic and never becomes the default route:

  * the port (or the VLAN sub-interface "sra<vlan>") gets the fixed address you typed,
  * a separate routing table (190) holds the SRA network (and the gateway, if you gave one),
  * remote-access connections made by the sensor program (source address = SRA address) and by the browser remote-desktop
    service (guacd, user "nobody") are sent through that table only. If the target is not reachable through the SRA port the
    connection fails - it is never sent out of the management port by accident.

Settings are kept in <state>/sra.json:  {"port": "eth2", "vlan": 0, "ip_cidr": "10.20.0.5/24", "gateway": "",
                                         "extra": [{"vlan": 30, "ip_cidr": "10.30.0.5/24"}]}
  - "port" alone is allowed: the port is reserved for remote access (role SRA, no capture) before any address is given.
  - "extra" = more VLAN networks on the same port, so the sensor can reach devices of other VLANs (it acts as the gateway
    into each of them: it has an address inside every VLAN).

This file also holds the per-site DNS / time-server settings (sitenet.json), shared by the screens and the web page.

  otsense-sra.py apply     bring the SRA port up from sra.json (or remove everything when it is not configured)
  otsense-sra.py show      print the settings and what is applied

Test without touching the system:  OTS_DRY=1 OTS_STATE=./state OTS_RUN=./run OTS_SYS=./fake-sys python3 otsense-sra.py apply
"""
import ipaddress, json, os, re, shlex, subprocess, sys

STATE = os.environ.get("OTS_STATE") or os.environ.get("STATE") or "/var/lib/otsense"
RUN = os.environ.get("OTS_RUN") or os.environ.get("RUN") or "/run/otsense"
SYS = os.environ.get("OTS_SYS", "/sys/class/net")
DRY = os.environ.get("OTS_DRY") == "1" or os.environ.get("DRY_RUN") == "1"
TABLE = 190
PRIO_SRC, PRIO_UID = 1190, 1191
GUAC_UID = 65534                      # guacd runs as "nobody" (see install-guacd.sh)
CFG = os.path.join(STATE, "sra.json")
ENVF = os.path.join(RUN, "sra.env")


def log(*a):
    print("[otsense-sra]", *a, flush=True)


def sh(cmd):
    if DRY:
        log("+", " ".join(cmd))
        return 0, ""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as e:      # noqa
        return 1, str(e)


def load():
    try:
        with open(CFG) as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save(cfg):
    os.makedirs(STATE, exist_ok=True)
    fd = os.open(CFG, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(cfg, f, indent=1)


def clear_cfg():
    try:
        os.remove(CFG)
    except OSError:
        pass


def ifname(cfg):
    """Interface that carries the SRA address: the port itself, or the VLAN sub-interface sra<vlan>."""
    v = int(cfg.get("vlan") or 0)
    return ("sra%d" % v) if v else str(cfg.get("port") or "")


def validate(cfg, other_ips=()):
    """-> (True, "") or (False, why). other_ips: addresses (with prefix) already on other ports, to catch an overlap."""
    port = str(cfg.get("port") or "")
    if not re.match(r"^[A-Za-z0-9_.:-]{1,15}$", port):
        return False, "No port chosen."
    try:
        v = int(cfg.get("vlan") or 0)
    except (TypeError, ValueError):
        return False, "VLAN must be a number from 1 to 4094 (0 or empty = no VLAN)."
    if v < 0 or v > 4094:
        return False, "VLAN must be a number from 1 to 4094 (0 or empty = no VLAN)."
    if not str(cfg.get("ip_cidr") or "").strip():
        return (False, "Give the main address first.") if cfg.get("extra") else (True, "")      # port only: reserved, no address yet
    try:
        ifc = ipaddress.ip_interface(str(cfg.get("ip_cidr") or ""))
    except ValueError:
        return False, "The address must be like 10.20.0.5/24 (address and prefix)."
    if ifc.version != 4 or ifc.network.prefixlen > 30 or ifc.ip == ifc.network.network_address or ifc.ip == ifc.network.broadcast_address:
        return False, "Use a normal IPv4 host address with a prefix from /8 to /30, e.g. 10.20.0.5/24."
    if not ifc.ip.is_private or ifc.ip.is_loopback or ifc.ip.is_link_local:
        return False, "The SRA address must be a private address (10.x, 172.16-31.x or 192.168.x)."
    gw = str(cfg.get("gateway") or "").strip()
    if gw:
        try:
            g = ipaddress.ip_address(gw)
        except ValueError:
            return False, "The gateway is not a valid address (or leave it empty)."
        if g not in ifc.network or g == ifc.ip:
            return False, "The gateway must be an address inside the SRA network %s." % ifc.network
    seen = [(v, ifc.network)]
    for e in (cfg.get("extra") or []):
        try:
            ev = int(e.get("vlan") or 0)
            ei = ipaddress.ip_interface(str(e.get("ip_cidr") or ""))
        except (TypeError, ValueError, AttributeError):
            return False, "A VLAN network is not valid (needs a VLAN number 1-4094 and an address like 10.30.0.5/24)."
        if ev < 1 or ev > 4094 or ei.version != 4 or ei.network.prefixlen > 30 or not ei.ip.is_private:
            return False, "VLAN %s: use a VLAN number 1-4094 and a private IPv4 address with prefix /8 to /30." % ev
        for (v2, n2) in seen:
            if v2 == ev:
                return False, "VLAN %d is used twice." % ev
            if n2.overlaps(ei.network):
                return False, "The network %s of VLAN %d overlaps %s." % (ei.network, ev, n2)
        seen.append((ev, ei.network))
    for o in other_ips:
        try:
            if ipaddress.ip_interface(o).network.overlaps(ifc.network):
                return False, "The SRA network %s overlaps the network %s of another port. Use a different network (or VLAN)." % (ifc.network, ipaddress.ip_interface(o).network)
        except ValueError:
            continue
    return True, ""


def other_addresses(skip=()):
    """IPv4 addresses with prefix currently on all ports except those named in skip."""
    out = []
    if DRY:
        return out
    rc, o = sh(["ip", "-o", "-4", "addr", "show"])
    for ln in (o or "").splitlines():
        p = ln.split()
        if len(p) > 3 and p[1] not in skip and p[1] != "lo":
            out.append(p[3])
    return out


def remove_all():
    """Take away every rule / route / sub-interface this script ever made, and the env file the sensor reads."""
    for pr in (PRIO_SRC, PRIO_UID):
        for _ in range(4):
            sh(["ip", "rule", "del", "priority", str(pr)])
    sh(["ip", "route", "flush", "table", str(TABLE)])
    if not DRY:
        try:
            for n in os.listdir(SYS):
                if re.match(r"^sra\d+$", n):
                    sh(["ip", "link", "del", n])
        except OSError:
            pass
    try:
        os.remove(ENVF)
    except OSError:
        pass


def apply():
    cfg = load()
    if not cfg.get("port"):
        remove_all()
        log("not configured - no SRA port")
        return 0
    if not cfg.get("ip_cidr"):          # port chosen, address not given yet: the port is reserved (no capture, no address)
        remove_all()
        if os.path.exists(os.path.join(SYS, str(cfg["port"]))) or DRY:
            sh(["ip", "addr", "flush", "dev", str(cfg["port"])])
            sh(["ip", "link", "set", str(cfg["port"]), "promisc", "off"])
            sh(["ip", "link", "set", str(cfg["port"]), "up"])
        log("SRA port %s reserved - no address yet" % cfg["port"])
        return 0
    ok, why = validate(cfg)
    if not ok:
        remove_all()
        log("settings not valid, SRA port left off:", why)
        return 1
    port = str(cfg["port"])
    if not DRY and not os.path.exists(os.path.join(SYS, port)):
        remove_all()
        log("port %s is not present - SRA port left off" % port)
        return 1
    vlan = int(cfg.get("vlan") or 0)
    ifn = ifname(cfg)
    ifc = ipaddress.ip_interface(cfg["ip_cidr"])
    gw = str(cfg.get("gateway") or "").strip()
    remove_all()
    # the port: up, no capture mode, no stray addresses
    sh(["ip", "link", "set", port, "promisc", "off"])
    sh(["ip", "link", "set", port, "up"])
    if vlan:
        sh(["modprobe", "8021q"])
        sh(["ip", "addr", "flush", "dev", port])
        rc, o = sh(["ip", "link", "add", "link", port, "name", ifn, "type", "vlan", "id", str(vlan)])
        if rc != 0:
            log("could not create VLAN %d on %s: %s" % (vlan, port, o.strip()[:120]))
            return 1
        sh(["ip", "link", "set", ifn, "up"])
    sh(["ip", "addr", "flush", "dev", ifn])
    # the SRA port must not answer ARP for / take over the management address and must accept replies on its own route
    for k, v in (("arp_ignore", "1"), ("arp_announce", "2"), ("rp_filter", "2")):
        sh(["sysctl", "-qw", "net.ipv4.conf.%s.%s=%s" % (ifn, k, v)])
    sh(["sysctl", "-qw", "net.ipv6.conf.%s.disable_ipv6=1" % ifn])
    sh(["ip", "addr", "add", cfg["ip_cidr"], "dev", ifn])
    # own routing table: the SRA network, the gateway if any, and "unreachable" for everything else (never fall back to management)
    sh(["ip", "route", "replace", str(ifc.network), "dev", ifn, "src", str(ifc.ip), "table", str(TABLE)])
    if gw:
        sh(["ip", "route", "replace", "default", "via", gw, "dev", ifn, "table", str(TABLE)])
    else:
        sh(["ip", "route", "replace", "unreachable", "default", "metric", "4000", "table", str(TABLE)])
    sh(["ip", "rule", "add", "from", "%s/32" % ifc.ip, "lookup", str(TABLE), "priority", str(PRIO_SRC)])
    sh(["ip", "rule", "add", "uidrange", "%d-%d" % (GUAC_UID, GUAC_UID), "lookup", str(TABLE), "priority", str(PRIO_UID)])
    nets = ["%s=%s" % (ifc.network, ifc.ip)]
    for e in (cfg.get("extra") or []):               # more VLANs on the same port: the sensor has an address inside each of them
        ev = int(e["vlan"])
        en = "sra%d" % ev
        ei = ipaddress.ip_interface(e["ip_cidr"])
        sh(["modprobe", "8021q"])
        rc, o = sh(["ip", "link", "add", "link", port, "name", en, "type", "vlan", "id", str(ev)])
        if rc != 0:
            log("could not create VLAN %d on %s: %s" % (ev, port, o.strip()[:120]))
            continue
        sh(["ip", "link", "set", en, "up"])
        for k, v in (("arp_ignore", "1"), ("arp_announce", "2"), ("rp_filter", "2")):
            sh(["sysctl", "-qw", "net.ipv4.conf.%s.%s=%s" % (en, k, v)])
        sh(["sysctl", "-qw", "net.ipv6.conf.%s.disable_ipv6=1" % en])
        sh(["ip", "addr", "add", e["ip_cidr"], "dev", en])
        sh(["ip", "route", "replace", str(ei.network), "dev", en, "src", str(ei.ip), "table", str(TABLE)])
        sh(["ip", "rule", "add", "from", "%s/32" % ei.ip, "lookup", str(TABLE), "priority", str(PRIO_SRC)])
        nets.append("%s=%s" % (ei.network, ei.ip))
        log("SRA VLAN %d address %s" % (ev, e["ip_cidr"]))
    os.makedirs(RUN, exist_ok=True)
    fd = os.open(ENVF, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
    with os.fdopen(fd, "w") as f:
        f.write("OTSENSE_SRA_IP=%s\nOTSENSE_SRA_IFACE=%s\nOTSENSE_SRA_NETS=%s\n" % (shlex.quote(str(ifc.ip)), shlex.quote(ifn), shlex.quote(",".join(nets))))
    log("SRA port %s%s address %s%s" % (port, (" VLAN %d" % vlan) if vlan else "", cfg["ip_cidr"], (" gateway " + gw) if gw else ""))
    return 0


# ------------------------------------------------------------------ DNS / time server of this site (entered on the sensor)
def _sn():
    return os.environ.get("OTS_SITENET") or os.path.join(STATE, "sitenet.json")


def sitenet_load():
    try:
        with open(_sn()) as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _addr_list(txt):
    out = []
    for x in re.split(r"[ ,;]+", str(txt or "").strip()):
        if x and x not in out:
            out.append(x)
    return out


def sitenet_check(dns, ntp):
    """-> (dns_list, ntp_list, "") or (None, None, why). DNS servers must be IP addresses; time servers may also be names."""
    dl = _addr_list(dns)
    for x in dl:
        try:
            ipaddress.ip_address(x)
        except ValueError:
            return None, None, "DNS server %r is not an IP address (like 192.168.1.1)." % x
    nl = _addr_list(ntp)
    for x in nl:
        if not re.match(r"^[A-Za-z0-9.:-]{1,100}$", x):
            return None, None, "Time server %r is not valid (an address or a name like pool.ntp.org)." % x
    if len(dl) > 3:
        return None, None, "Give at most 3 DNS servers."
    return dl, nl, ""


def sitenet_save(dns, ntp):
    dl, nl, why = sitenet_check(dns, ntp)
    if why:
        return False, why
    os.makedirs(STATE, exist_ok=True)
    fd = os.open(_sn(), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
    with os.fdopen(fd, "w") as f:
        json.dump({"dns": ", ".join(dl), "ntp": ", ".join(nl)}, f)
    return True, ""


def sitenet_apply():
    """Put the saved DNS / time servers to work: resolv.conf now, and the DHCP client keeps them (supersede); timesyncd restarts."""
    d = sitenet_load()
    dl, nl = _addr_list(d.get("dns")), _addr_list(d.get("ntp"))
    out = []
    if DRY:
        return ["dry run: dns %s ntp %s" % (dl, nl)]
    if dl:
        try:
            with open("/etc/resolv.conf", "w") as f:
                f.write("# set by OT Sense (site DNS)\n" + "".join("nameserver %s\n" % x for x in dl))
            out.append("DNS: " + ", ".join(dl))
        except OSError as e:
            out.append("DNS not written: %s" % e)
    try:                                              # keep the DHCP client from overwriting it
        cf = "/etc/dhcp/dhclient.conf"
        txt = open(cf).read() if os.path.exists(cf) else ""
        txt = re.sub(r"\n?# OTSENSE-BEGIN.*?# OTSENSE-END\n?", "\n", txt, flags=re.S)
        if dl:
            txt += "\n# OTSENSE-BEGIN\nsupersede domain-name-servers %s;\n# OTSENSE-END\n" % ", ".join(dl)
        if os.path.isdir("/etc/dhcp"):
            with open(cf, "w") as f:
                f.write(txt)
    except OSError:
        pass
    if nl:
        try:
            os.makedirs("/etc/systemd/timesyncd.conf.d", exist_ok=True)
            with open("/etc/systemd/timesyncd.conf.d/otsense.conf", "w") as f:
                f.write("[Time]\nNTP=%s\n" % " ".join(nl))
            sh(["timedatectl", "set-ntp", "true"])
            sh(["systemctl", "restart", "systemd-timesyncd"])
            out.append("Time server: " + ", ".join(nl))
        except OSError as e:
            out.append("Time server not written: %s" % e)
    return out


def show():
    cfg = load()
    print(json.dumps({"config": cfg, "interface": ifname(cfg) if cfg.get("port") else "", "env": open(ENVF).read() if os.path.exists(ENVF) else ""}, indent=1))
    return 0


if __name__ == "__main__":
    a = sys.argv[1] if len(sys.argv) > 1 else "apply"
    sys.exit(apply() if a == "apply" else show() if a == "show" else (print("\n".join(sitenet_apply())) or 0) if a == "sitenet" else 2)
