#!/bin/bash
# Started on tty1 by otsense-console.service: tries the graphical screen (buttons, same as the ISO / OVA screen); if the graphics cannot start
# it falls back to the text screen by itself. Nobody has to type anything.
export D=/opt/otsense TERM=linux HOME=/root
mkdir -p /run/otsense
while true; do
  T0=$(date +%s)
  if [ -x /usr/bin/xinit ] && [ -x /usr/bin/Xorg ] && python3 -c 'import tkinter' 2>/dev/null && [ ! -f /run/otsense/no-gui ]; then
    xinit /usr/bin/python3 /opt/otsense/otsense-gui.py -- /usr/bin/Xorg :0 vt1 -nolisten tcp -quiet >/run/otsense/gui.log 2>&1
    RC=$?
    if [ "$RC" = 3 ] || [ $(( $(date +%s) - T0 )) -lt 15 ]; then touch /run/otsense/no-gui; fi
  fi
  python3 /opt/otsense/otsense-console.py
  sleep 2
done
