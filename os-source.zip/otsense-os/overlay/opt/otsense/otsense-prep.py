#!/usr/bin/env python3
"""OT Sense OS - boot preparation. Runs at every boot BEFORE NetworkManager and the sensor.

1. Imports the site settings that central stamped into the image (file otsense-slot.bin on the small boot/FAT partition)
   or that you copied there, keeps them in /var/lib/otsense/slot.json and blanks the file (it holds the token / Wi-Fi password).
2. Decides the port roles: ONE management port (Wi-Fi or Ethernet), at most ONE remote-access (SRA) port (sra.json, chosen on the
   console screen; own IP / VLAN, see otsense-sra.py) and any number of SPAN / capture ports.
   Choice made on the console screen (ports.json, "manual") wins, otherwise automatic rules apply.
3. Writes NetworkManager connection files for the management port, and marks every SPAN port "unmanaged" (no IP, no DHCP, nothing sent).
4. Writes /run/otsense/env for run-sensor.sh.

Test without touching the system:  OTS_DRY=1 OTS_SYS=./fake-sys OTS_STATE=./state OTS_RUN=./run OTS_NM=./nm python3 otsense-prep.py
"""
import hashlib, json, os, re, secrets, shlex, struct, subprocess, sys, uuid

MAGIC = b"OTSENSE_SLOT_V1" + bytes([10])      # built at run time on purpose: a compiled .pyc must not contain the whole marker (the image self-check counts it)
SLOT = 65536
DRY = os.environ.get("OTS_DRY") == "1"
SYS = os.environ.get("OTS_SYS", "/sys/class/net")
STATE = os.environ.get("OTS_STATE", "/var/lib/otsense")
RUN = os.environ.get("OTS_RUN", "/run/otsense")
NMDIR = os.environ.get("OTS_NM", "/etc/NetworkManager")
SLOT_FILES = [x for x in os.environ.get("OTS_SLOTFILES", "/boot/firmware/otsense-slot.bin:/boot/efi/otsense-slot.bin:/boot/otsense-slot.bin").split(":") if x]
SKIP = ("lo", "docker", "veth", "br-", "virbr", "tun", "tap", "ifb", "bond", "dummy", "sit", "gre", "ip6tnl", "wg", "tailscale", "vmnet", "vboxnet", "zt", "usb0", "bnep", "p2p")


def log(*a):
    print("[otsense-prep]", *a, flush=True)


def sh(cmd, check=False):
    if DRY:
        log("+", " ".join(cmd))
        return 0
    try:
        return subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30, check=check).returncode
    except Exception:
        return 1


def rd(path, default=""):
    try:
        with open(path, "r") as f:
            return f.read().strip()
    except OSError:
        return default


def wr(path, text, mode=0o644):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    with os.fdopen(fd, "w") as f:
        f.write(text)
    os.chmod(path, mode)


def natkey(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s)]


# ---------------------------------------------------------------- slot
def parse_slot(data):
    """-> dict, or None when the file is blank / not a slot."""
    if data[:16] != MAGIC or len(data) < 20:
        return None
    n = struct.unpack(">I", data[16:20])[0]
    if n == 0 or n > SLOT - 20:
        return None
    try:
        d = json.loads(data[20:20 + n].decode("utf-8"))
    except Exception:
        return None
    return d if isinstance(d, dict) else None


def blank_slot_file(path):
    try:
        with open(path, "r+b") as f:
            f.write(MAGIC + bytes(SLOT - len(MAGIC)))
            f.flush()
            os.fsync(f.fileno())
    except OSError as e:
        log("could not blank", path, e)


def import_slot():
    """Returns True when a new slot was imported."""
    for p in SLOT_FILES:
        if not os.path.isfile(p):
            continue
        try:
            with open(p, "rb") as f:
                data = f.read(SLOT)
        except OSError:
            continue
        d = parse_slot(data)
        if d is None:
            continue
        d["_imported"] = True
        os.makedirs(STATE, exist_ok=True)
        wr(os.path.join(STATE, "slot.json"), json.dumps(d, indent=1), 0o600)
        # a fresh stamp means "start from the stamped settings": forget manual port choices of an older run
        try:
            os.remove(os.path.join(STATE, "ports.json"))
        except OSError:
            pass
        log("imported site settings from", p, "- site", d.get("site"))
        if not DRY:
            blank_slot_file(p)
        return True
    return False


def load_cfg():
    try:
        with open(os.path.join(STATE, "slot.json")) as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


# ---------------------------------------------------------------- ports
def discover():
    out = []
    try:
        names = os.listdir(SYS)
    except OSError:
        return out
    for n in sorted(names, key=natkey):
        if n.startswith(SKIP) or n == "lo":
            continue
        b = os.path.join(SYS, n)
        if not os.path.exists(os.path.join(b, "device")):
            continue
        wifi = os.path.exists(os.path.join(b, "wireless")) or os.path.exists(os.path.join(b, "phy80211"))
        if not wifi and rd(os.path.join(b, "type")) != "1":
            continue
        out.append({"name": n, "wifi": wifi, "mac": rd(os.path.join(b, "address")), "carrier": rd(os.path.join(b, "carrier")) == "1"})
    return out


def auto_roles(nics, cfg):
    """Automatic rules (used until someone chooses on the console screen).
    - Wi-Fi settings in the stamp (or mgmt=wifi): Wi-Fi = management, every wired port = SPAN (Raspberry Pi: eth0 = SPAN).
    - Otherwise: first wired port = management, all other wired ports = SPAN (VM with 4 ports: 1 + 3).
    - Only one wired port and no Wi-Fi: it is the management port, no capture."""
    wired = [n["name"] for n in nics if not n["wifi"]]
    wifi = [n["name"] for n in nics if n["wifi"]]
    pref = str(cfg.get("mgmt") or "auto").lower()
    want_wifi = bool(wifi) and (pref == "wifi" or (pref == "auto" and cfg.get("wifi_ssid")))
    if pref == "eth":
        want_wifi = False
    if want_wifi:
        mgmt, span = wifi[0], list(wired)
    elif wired:
        mgmt, span = wired[0], wired[1:]
    elif wifi:
        mgmt, span = wifi[0], []
    else:
        mgmt, span = "", []
    if isinstance(cfg.get("span"), list) and cfg["span"]:
        span = [s for s in cfg["span"] if s != mgmt and any(n["name"] == s for n in nics)] or span
    return {"mgmt": mgmt, "span": span, "manual": False}


def resolve_sra(roles, nics):
    """The remote-access (SRA) port is chosen in sra.json. It is a wired port that is not the management port; it is never a SPAN port."""
    roles["sra"] = ""
    try:
        with open(os.path.join(STATE, "sra.json")) as f:
            c = json.load(f)
    except (OSError, ValueError):
        return roles
    p = c.get("port") if isinstance(c, dict) else ""
    if p and p != roles["mgmt"] and any(n["name"] == p and not n["wifi"] for n in nics):
        roles["sra"] = p
        roles["span"] = [s for s in roles["span"] if s != p]
    return roles


def load_ports(nics, cfg):
    return resolve_sra(_load_ports(nics, cfg), nics)


def _load_ports(nics, cfg):
    names = {n["name"] for n in nics}
    try:
        with open(os.path.join(STATE, "ports.json")) as f:
            p = json.load(f)
        if p.get("manual"):
            mg = p.get("mgmt") if p.get("mgmt") in names else ""
            sp = [s for s in p.get("span", []) if s in names and s != mg]
            return {"mgmt": mg, "span": sp, "manual": True}
    except (OSError, ValueError):
        pass
    return auto_roles(nics, cfg)


# ---------------------------------------------------------------- NetworkManager files
def q(s):
    s = str(s)
    if re.search(r"[\x00-\x1f\x7f]", s):
        raise ValueError("control character in a setting")
    return s


def ip_block(cfg):
    if str(cfg.get("mode")) == "static" and cfg.get("ip_cidr") and cfg.get("gateway"):
        dns = ";".join(x for x in re.split(r"[ ,;]+", str(cfg.get("dns") or "")) if x)
        t = "[ipv4]\nmethod=manual\naddress1=%s,%s\n" % (q(cfg["ip_cidr"]), q(cfg["gateway"]))
        if dns:
            t += "dns=%s;\n" % dns
        return t + "\n[ipv6]\nmethod=ignore\n"
    return "[ipv4]\nmethod=auto\nmay-fail=false\n\n[ipv6]\nmethod=auto\n"


def nm_keyfile_wired(ifname, cfg):
    return ("[connection]\nid=otsense-mgmt\nuuid=%s\ntype=ethernet\ninterface-name=%s\nautoconnect=true\nautoconnect-priority=100\n\n[ethernet]\n\n%s"
            % (uuid.uuid5(uuid.NAMESPACE_DNS, "otsense-mgmt-eth"), q(ifname), ip_block(cfg)))


def nm_keyfile_wifi(ifname, cfg):
    ssid = q(cfg.get("wifi_ssid") or "")
    psk = q(cfg.get("wifi_psk") or "")
    t = "[connection]\nid=otsense-wifi\nuuid=%s\ntype=wifi\ninterface-name=%s\nautoconnect=true\nautoconnect-priority=100\n\n" % (
        uuid.uuid5(uuid.NAMESPACE_DNS, "otsense-mgmt-wifi"), q(ifname))
    t += "[wifi]\nmode=infrastructure\nssid=%s\n%s\n" % (ssid, "hidden=true\n" if cfg.get("wifi_hidden") else "")
    if psk:
        t += "[wifi-security]\nkey-mgmt=wpa-psk\npsk=%s\n\n" % psk
    return t + ip_block(cfg)


def write_network(roles, cfg, nics, nm_live):
    d = os.path.join(NMDIR, "system-connections")
    os.makedirs(d, exist_ok=True)
    for f in os.listdir(d):
        if f.startswith("otsense-") and f.endswith(".nmconnection"):
            os.remove(os.path.join(d, f))
    mg = roles["mgmt"]
    kind = next((n for n in nics if n["name"] == mg), None)
    if mg and kind:
        if kind["wifi"]:
            if cfg.get("wifi_ssid"):
                wr(os.path.join(d, "otsense-wifi.nmconnection"), nm_keyfile_wifi(mg, cfg), 0o600)
            else:
                log("Wi-Fi is the management port but no network is set yet: use the console screen (W)")
        else:
            wr(os.path.join(d, "otsense-mgmt.nmconnection"), nm_keyfile_wired(mg, cfg), 0o600)
    un = ["interface-name:%s" % s for s in roles["span"] + ([roles["sra"]] if roles.get("sra") else [])]      # SPAN and SRA ports: NetworkManager must not touch them
    conf = "[main]\nno-auto-default=*\n"
    if un:
        conf += "\n[keyfile]\nunmanaged-devices=%s\n" % ";".join(un)
    wr(os.path.join(NMDIR, "conf.d", "90-otsense-ports.conf"), conf, 0o644)
    if nm_live:      # running again later (console screen changed something): make NetworkManager notice
        for s in roles["span"]:
            sh(["nmcli", "device", "set", s, "managed", "no"])
        sh(["nmcli", "connection", "reload"])
        if mg:
            sh(["nmcli", "device", "set", mg, "managed", "yes"])
            sh(["nmcli", "connection", "up", "otsense-wifi" if kind and kind["wifi"] else "otsense-mgmt", "ifname", mg])


def apply_system(cfg):
    host = re.sub(r"[^A-Za-z0-9-]+", "-", str(cfg.get("hostname") or "otsense-" + str(cfg.get("site") or "sensor"))).strip("-").lower()[:40] or "otsense"
    if cfg.get("hostname") and re.match(r"^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$", str(cfg["hostname"])):
        host = str(cfg["hostname"])[:63]
    if not DRY:
        wr("/etc/hostname", host + "\n")
        try:
            with open("/proc/sys/kernel/hostname", "w") as f:
                f.write(host.split(".")[0])
        except OSError:
            pass
        h = rd("/etc/hosts")
        h = "\n".join(l for l in h.splitlines() if not l.startswith("127.0.1.1")) + "\n127.0.1.1\t%s\n" % host
        wr("/etc/hosts", h)
    ntp = [x for x in re.split(r"[ ,;]+", str(cfg.get("ntp") or "")) if re.match(r"^[A-Za-z0-9][A-Za-z0-9.-]*$", x)]
    if ntp and not DRY:
        wr("/etc/systemd/timesyncd.conf.d/otsense.conf", "[Time]\nNTP=%s\n" % " ".join(ntp))
    cc = str(cfg.get("wifi_country") or "").upper()
    if re.match(r"^[A-Z]{2}$", cc):
        if not DRY:
            wr("/etc/modprobe.d/otsense-regdom.conf", "options cfg80211 ieee80211_regdom=%s\n" % cc)
        sh(["iw", "reg", "set", cc])
    sh(["rfkill", "unblock", "wifi"])          # Raspberry Pi OS ships with Wi-Fi switched off until a country is chosen
    pw = cfg.get("console_password")
    if not pw:
        f = os.path.join(STATE, "console-pw")
        pw = rd(f) or secrets.token_urlsafe(9)
        if not os.path.exists(f):
            wr(f, pw + "\n", 0o600)
    if not DRY:
        try:       # one login: "user" and "otsense" get the web password; once central has set it (STATE/ui-password) that one is used
            pw = rd(os.path.join(STATE, "ui-password")) or pw
            subprocess.run(["chpasswd"], input=("user:%s\notsense:%s\n" % (pw, pw)).encode(), timeout=20, check=False)
        except Exception:
            pass
    return host, pw


def main():
    os.makedirs(STATE, exist_ok=True)
    os.makedirs(RUN, exist_ok=True)
    imported = import_slot()
    cfg = load_cfg()
    import time
    for _ in range(0 if DRY else 8):          # a USB network adapter may need a few seconds
        if discover():
            break
        time.sleep(1)
    nics = discover()
    roles = load_ports(nics, cfg)
    host, pw = apply_system(cfg)
    nm_live = (not DRY) and subprocess.run(["systemctl", "is-active", "--quiet", "NetworkManager"]).returncode == 0
    write_network(roles, cfg, nics, nm_live)
    ca = ""
    if cfg.get("ca_pem"):
        ca = os.path.join(STATE, "ca-from-stamp.pem")
        wr(ca, str(cfg["ca_pem"]).strip() + "\n", 0o644)
    else:
        ca = "/etc/ssl/certs/ca-certificates.crt"
    env = {"SITE": cfg.get("site", ""), "CENTRAL": cfg.get("central", ""), "TOKEN": cfg.get("token", ""), "SCAN": cfg.get("scan", ""),
           "CAFILE": ca, "MGMT": roles["mgmt"], "CAP": ",".join(roles["span"]), "SRA": roles.get("sra", ""), "WEBPW": pw, "HOST": host,
           "CONFIGURED": "1" if (cfg.get("central") and cfg.get("token")) else "0", "MANUAL": "1" if roles["manual"] else "0"}
    wr(os.path.join(RUN, "env"), "".join("%s=%s\n" % (k, shlex.quote(str(v))) for k, v in env.items()), 0o600)
    log("site=%s management=%s remote-access=%s capture=%s (%s) configured=%s" % (env["SITE"] or "-", roles["mgmt"] or "none", env["SRA"] or "none", env["CAP"] or "none",
        "chosen on screen" if roles["manual"] else "automatic", env["CONFIGURED"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
