#!/bin/sh
# otsense-container: manages the OT Sense sensor container on this Linux machine. Run as root.
#   otsense-container status | logs | update | rollback | iface <port> | remove
# Only the container is ever replaced. The machine's own network settings are never changed.
P=/opt/otsense-container; CONF="$P/conf"
[ "$(id -u)" -eq 0 ] || { echo "Run as root:  sudo otsense-container $*"; exit 1; }
[ -f "$CONF" ] || { echo "Not installed here ($CONF is missing)."; exit 1; }
# shellcheck disable=SC1090
. "$CONF"
IMG=otsense-sensor; NAME=otsense-sensor

detect_ports() {   # management = port with the default route; capture = first real port without an IP address
  MGMT="$(ip -o -4 route show default 2>/dev/null | awk '{print $5; exit}')"; CAP=""
  for n in $(ls /sys/class/net); do
    case "$n" in lo|docker*|veth*|br-*|virbr*|tun*|tap*|ifb*|bond*|wl*) continue;; esac
    [ -e "/sys/class/net/$n/device" ] || continue
    [ "$n" = "$MGMT" ] && continue
    ip -o -4 addr show dev "$n" 2>/dev/null | grep -q . && continue
    CAP="$n"; break
  done
}
run_container() {  # $1 = container name, $2 = image tag
  MOUNT=""; [ -d "$P/pack" ] && MOUNT="-v $P/pack:/pack:ro"
  # shellcheck disable=SC2086
  docker run -d --name "$1" --restart unless-stopped --network host --cap-add NET_RAW --cap-add NET_ADMIN \
    -v otsense-sensor:/data $MOUNT \
    -e OTSENSE_SITE="$SITE" -e OTSENSE_CENTRAL="$CENTRAL" -e OTSENSE_TOKEN="$TOKEN" -e OTSENSE_IFACE="$IFACE" -e OTSENSE_MGMT="$MGMT" \
    -e OTSENSE_UI_PORT="${UIPORT:-8081}" ${FIRST:+-e OTSENSE_FORCE_CONFIG=1} "$IMG:$2" >/dev/null
}
fetch_ctx() {
  rm -rf "$P/ctx.new"; mkdir -p "$P/ctx.new"
  curl -fsSL -H "Authorization: Bearer $TOKEN" "$CENTRAL/api/sensor/container/context.tgz" -o "$P/ctx.tgz" || { echo "Cannot download from central ($CENTRAL)."; return 1; }
  tar xzf "$P/ctx.tgz" -C "$P/ctx.new" || return 1
  [ -f "$P/ctx.new/Dockerfile" ] || { echo "Download is not a sensor package."; return 1; }
  rm -rf "$P/ctx"; mv "$P/ctx.new" "$P/ctx"
}
healthy_wait() {   # wait up to 150 s for the new container to be healthy
  i=0
  while [ $i -lt 30 ]; do
    st="$(docker inspect -f '{{.State.Health.Status}}' "$NAME" 2>/dev/null)"; run="$(docker inspect -f '{{.State.Running}}' "$NAME" 2>/dev/null)"
    [ "$st" = "healthy" ] && return 0
    [ "$run" = "false" ] && return 1
    sleep 5; i=$((i+1))
  done
  return 1
}
do_update() {
  command -v docker >/dev/null || { echo "Docker is not installed."; exit 1; }
  fetch_ctx || exit 1
  echo "Building the sensor container..."
  docker build -q -t "$IMG:new" "$P/ctx" >/dev/null || { echo "Build failed. The running sensor was NOT touched."; exit 1; }
  [ -d "$P/pack" ] || true
  detect_ports; [ -n "$IFACE" ] || IFACE="$CAP";
  # keep the working one as a fallback
  if docker image inspect "$IMG:current" >/dev/null 2>&1; then docker tag "$IMG:current" "$IMG:previous"; fi
  docker tag "$IMG:new" "$IMG:current"
  if docker inspect "$NAME" >/dev/null 2>&1; then
    docker rm -f "$NAME-old" >/dev/null 2>&1 || true
    docker stop "$NAME" >/dev/null 2>&1; docker rename "$NAME" "$NAME-old"; docker update --restart=no "$NAME-old" >/dev/null 2>&1 || true
    HAD=1
  else HAD=""; FIRST=1; fi
  run_container "$NAME" current
  echo "Waiting for the new sensor to report healthy (up to 2 minutes)..."
  if healthy_wait; then
    docker rm -f "$NAME-old" >/dev/null 2>&1 || true
    echo "OK - the sensor container is running and healthy."
  else
    echo "The new container did not become healthy."
    docker logs --tail 20 "$NAME" 2>&1 | sed 's/^/   /'
    docker rm -f "$NAME" >/dev/null 2>&1 || true
    if [ -n "$HAD" ]; then
      docker rename "$NAME-old" "$NAME"; docker update --restart=unless-stopped "$NAME" >/dev/null 2>&1; docker start "$NAME" >/dev/null
      docker image inspect "$IMG:previous" >/dev/null 2>&1 && docker tag "$IMG:previous" "$IMG:current"
      echo "The OLD sensor container was started again. Nothing is lost."
    fi
    exit 1
  fi
}
case "${1:-status}" in
  install|update) [ "$1" = install ] && FIRST=1; do_update ;;
  rollback)
    docker image inspect "$IMG:previous" >/dev/null 2>&1 || { echo "No earlier version is stored."; exit 1; }
    docker rm -f "$NAME" >/dev/null 2>&1 || true
    docker tag "$IMG:previous" "$IMG:current"; run_container "$NAME" current && echo "Earlier container version is running." ;;
  iface) [ -n "$2" ] || { echo "usage: otsense-container iface <capture port>"; exit 1; }
    sed -i '/^IFACE=/d' "$CONF"; echo "IFACE=\"$2\"" >> "$CONF"; IFACE="$2"; detect_ports
    docker rm -f "$NAME" >/dev/null 2>&1 || true; run_container "$NAME" current && echo "Capture port set to $2." ;;
  status) docker ps -a --filter "name=^$NAME" --format 'container: {{.Names}}  {{.Status}}'; docker image ls "$IMG" --format 'image: {{.Repository}}:{{.Tag}}  {{.CreatedSince}}'; echo "central: $CENTRAL   site: $SITE   capture port: ${IFACE:-not set}" ;;
  logs) docker logs --tail 80 "$NAME" ;;
  remove) docker rm -f "$NAME" "$NAME-old" >/dev/null 2>&1; echo "Container removed. Settings volume 'otsense-sensor' kept (docker volume rm otsense-sensor to delete it)." ;;
  *) echo "usage: otsense-container status | logs | update | rollback | iface <port> | remove" ;;
esac
