#!/bin/sh
# OT Sense sensor container. State (settings, saved software update) lives in /data (a Docker volume), so the container can be replaced any time.
set -e
cd /opt/otsense
D=/data; mkdir -p "$D"
[ "${1:-sensor}" = "cli" ] && { shift; exec python3 otsense.py "$@"; }
[ "${1:-}" = "sensor" ] && shift          # what is left are extra options for the sensor (the images pass --ui-password)
[ "${OTSENSE_HOSTCTL:-0}" = 1 ] && export PATH="/opt/hostctl:$PATH"
# a software update sent from central is kept in /data/code; put it back after the container was re-created. The restore script drops it
# again if it did not start properly twice in a row, or if the program inside the image is newer.
[ -f "$D/code/restore.py" ] && { python3 "$D/code/restore.py" /opt/otsense "$D/code" || true; }
[ "${OTSENSE_FORCE_CONFIG:-0}" = 1 ] && rm -f "$D/sensor.json"
EXTRA=""
if [ -f /pack/ui.crt ] && [ -f /pack/ui.key ]; then EXTRA="--ui-cert /pack/ui.crt --ui-key /pack/ui.key"; fi
CA=""; [ -f /pack/ca.crt ] && CA="--cafile /pack/ca.crt"
if [ ! -f "$D/sensor.json" ] && [ -n "${OTSENSE_CENTRAL:-}" ]; then
  # shellcheck disable=SC2086
  python3 otsense.py appliance --state-dir "$D" --configure-only --site "${OTSENSE_SITE:-sensor}" \
    --central "$OTSENSE_CENTRAL" --token "$OTSENSE_TOKEN" $CA \
    ${OTSENSE_IFACE:+--iface "$OTSENSE_IFACE"} ${OTSENSE_MGMT:+--mgmt-iface "$OTSENSE_MGMT"} $EXTRA
fi
# shellcheck disable=SC2086
exec python3 otsense.py appliance --state-dir "$D" ${OTSENSE_UI_PORT:+--ui-port "$OTSENSE_UI_PORT"} $EXTRA "$@"
