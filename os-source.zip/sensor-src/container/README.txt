OT Sense sensor as a container (any Linux machine with Docker)
==============================================================
Install (from central: Sites > open the sensor's Dashboard > Manage this sensor > "Add Linux container sensor"):
  copy the one command it shows and run it as root on the Linux machine. It installs Docker if missing, builds the container
  from central, starts it and waits until the sensor has reached central.

What stays on the machine (never touched by container updates): IP address, DHCP/static, VLAN, DNS, ports, SSH.
What is in the container: the sensor program (alerts, vulnerabilities, web page, scanning, SRA).
Settings and saved software updates: Docker volume "otsense-sensor" (/data).

On the machine:  otsense-container status | logs | update | rollback | iface <capture port> | remove
 - update   rebuilds from central's current program; if the new container does not become healthy in 2 minutes the old one is started again.
 - A software update pushed from central replaces only the program inside the container; it is kept in the volume, and dropped
   automatically if it fails to start twice in a row.
 - rollback goes back to the previous container version.
Private certificate authority on central: put its ca.crt into /opt/otsense-container/pack/ca.crt before "update".
The sensor web page listens on port 8081 (UIPORT in /opt/otsense-container/conf) so it does not clash with a web server on the machine.
